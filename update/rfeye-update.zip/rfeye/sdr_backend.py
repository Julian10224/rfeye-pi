"""RF Eye SDR backend -- detector profile v8.

What changed and why
--------------------
Profiles up to v7 alerted on wideband energy statistics: channel power, duty
cycle, burst span, and how much those had moved since the previous sweep.
Those features cannot distinguish a C2000 handset from any other bursty RF,
so no threshold on them was ever going to work.  Field recordings showed the
consequence plainly: the duplex-pair gate passed 100% of the 390-395 MHz
channels it looked at, the novelty gate rejected nothing during busy sweeps,
and alerts landed on three neighbouring 25 kHz raster points at once -- which
one TETRA carrier physically cannot do.

v8 replaces that with a two-stage design:

  1. Lock the network.  Verify base station downlink carriers in 390-395 MHz
     against the real ETSI EN 300 392-2 waveform (see ``tetra_phy``).  Base
     stations transmit continuously, so they can be verified thoroughly and
     repeatedly.  No verified base station means no C2000 coverage here, and
     the device stays silent instead of guessing.

  2. Watch the band.  Every 25 kHz channel of 380-385 MHz is dwelled on and
     verified with the same physical-layer tests, whether or not a downlink is
     locked.  Only a verified TETRA uplink transmission raises an alert.

     Until 0.9.35 this stage watched only the duplex partners of the locked
     downlinks -- on the reference unit two channels of the two hundred the
     band holds.  A vehicle registered on any other carrier, or on a
     neighbouring site, transmitted into a receiver that was not listening
     there, which is why an ambulance could drive past and raise nothing: a
     coverage problem, not a sensitivity one.  The lock still decides which
     channels confirm on a single hit, and it is still what the panel
     reports, but it is no longer the gate on hearing anything.

Every alert therefore rests on demodulated evidence -- pi/4-DQPSK at exactly
18000 symbols/s, a 25 kHz RRC channel shape, and 14.1667 ms TDMA slot timing
-- rather than on a level crossing a threshold.

The artefact baseline, coherent-comb rejector, temporal novelty gate and
duplex-pair scoring of v6/v7 are gone.  They were all attempts to subtract
false positives after the fact, and with a real waveform test they are not
only unnecessary but harmful: each one could also suppress a genuine
detection.
"""
import math, os, shutil, subprocess, threading, time, ctypes, ctypes.util
from pathlib import Path

import numpy as np

import tetra_phy
from tetra_phy import Channelizer, PhyResult, clamp
from tetra_detector import (SiteRegistry, UplinkAlarm, carrier_number, plan_dwell,
                            raster_snap)
from power import PowerLadder, read_soc_temp, read_uv_alarm

try:
    from rtlsdr import RtlSdr
except Exception:
    RtlSdr = None


# A driver that does not know this dongle is indistinguishable from a dead
# band, so the marker for the newest model is what a library is judged on.
RTLSDR_MODEL_MARKER = b'Blog V4L'


def rtlsdr_library_candidates():
    """Where to look for librtlsdr, best first."""
    out=[]
    override=os.environ.get('RFEYE_RTLSDR_LIB','').strip()
    if override:
        out.append(override)
    # Where install.sh puts the RTL-SDR Blog build. Ahead of find_library on
    # purpose: both are in the loader cache and which one it returns is not
    # something to leave to chance.
    out.extend(['/usr/local/lib/librtlsdr.so.0','/usr/local/lib/librtlsdr.so'])
    found=ctypes.util.find_library('rtlsdr')
    if found:
        out.append(found)
    out.append('librtlsdr.so.0')
    seen=set(); uniq=[]
    for x in out:
        if x and x not in seen:
            seen.add(x); uniq.append(x)
    return uniq


def _library_knows_model(path):
    """Does this build carry the newest dongle's code path?

    Read as bytes rather than probed through the API: the model check is
    internal to librtlsdr and not exported, and a file is cheap to look at.
    """
    try:
        p=Path(path)
        if not p.is_absolute() or not p.is_file():
            return False
        return RTLSDR_MODEL_MARKER in p.read_bytes()
    except Exception:
        return False


def open_rtlsdr_library():
    """Load a librtlsdr that knows this hardware, not just the first one found.

    Debian's librtlsdr 2.0.2 has no code path for the RTL-SDR Blog V4L. That
    dongle carries an RF switch on a GPIO that routes the antenna either into
    the HF upconverter or straight to the tuner, and the tuner input has to be
    selected per band. A driver that does not know the model never throws
    either switch, so the antenna stays on the wrong branch and the whole UHF
    band reads as noise -- which looks exactly like no C2000 in range.

    Measured on the reference unit, same dongle and same air, four rounds
    alternating, 390.7375 MHz:

        Debian 2.0.2   snr 0.5-0.8 dB   bw 39.7 kHz   duty 0.00   FAIL
        RTL-SDR Blog   snr 11.7-13.4    bw 22.2 kHz   duty 1.00   TETRA

    Returns (handle, path, knows_model).
    """
    first=None
    for path in rtlsdr_library_candidates():
        try:
            lib=ctypes.CDLL(path)
        except OSError:
            continue
        if _library_knows_model(path):
            return lib,str(path),True
        if first is None:
            first=(lib,str(path))
    if first is None:
        raise RuntimeError('no usable librtlsdr found')
    return first[0],first[1],False


class _CapturePump:
    """Runs dwell captures on their own thread.

    The radio and the maths were strictly alternating: on the field unit a
    cycle was 0.70 s of capture followed by 0.93 s of analysis, so the receiver
    spent about a third of a cycle -- and 11% of wall-clock time -- actually
    listening to 380-385 MHz. Nothing about that is forced by the hardware; the
    dongle can fill a buffer while the previous one is being measured.

    Every read still happens on exactly one thread, this one, because the
    librtlsdr handle may not be touched from two at once. The scan thread only
    submits and waits, so ``_samples`` keeps its single owner and the tests
    keep their patch point.
    """

    def __init__(self, fn):
        self._fn = fn
        self._q = __import__('queue').Queue()
        self._thread = threading.Thread(target=self._run, name='rfeye-capture',
                                        daemon=True)
        self._thread.start()

    def submit(self, centre, sr, count):
        job = {'args': (centre, sr, count),
               'key': (int(round(float(centre))), int(sr), int(count)),
               'ev': threading.Event(), 'iq': None, 'err': None}
        self._q.put(job)
        return job

    def wait(self, job, timeout):
        if not job['ev'].wait(max(0.1, float(timeout))):
            raise RuntimeError('capture thread did not answer in time')
        if job['err'] is not None:
            raise job['err']
        return job['iq']

    def _run(self):
        while True:
            job = self._q.get()
            if job is None:
                break
            try:
                job['iq'] = self._fn(*job['args'])
            except BaseException as exc:            # reported to the waiter
                job['err'] = exc
            finally:
                job['ev'].set()

    def stop(self):
        self._q.put(None)


class _PersistentRTL:
    """Persistent librtlsdr wrapper using only stable C API calls.

    This avoids the pyrtlsdr/librtlsdr ABI mismatch seen on RTL-SDR Blog V4
    systems while keeping one USB device handle open across tuning windows.
    """
    def __init__(self, index=0):
        self.lib,self.lib_path,self.lib_knows_model=open_rtlsdr_library()
        self.dev=ctypes.c_void_p()
        self.lib.rtlsdr_open.argtypes=[ctypes.POINTER(ctypes.c_void_p),ctypes.c_uint32]
        self.lib.rtlsdr_open.restype=ctypes.c_int
        self.lib.rtlsdr_close.argtypes=[ctypes.c_void_p]
        self.lib.rtlsdr_set_sample_rate.argtypes=[ctypes.c_void_p,ctypes.c_uint32]
        self.lib.rtlsdr_set_center_freq.argtypes=[ctypes.c_void_p,ctypes.c_uint32]
        self.lib.rtlsdr_set_freq_correction.argtypes=[ctypes.c_void_p,ctypes.c_int]
        self.lib.rtlsdr_set_tuner_gain_mode.argtypes=[ctypes.c_void_p,ctypes.c_int]
        self.lib.rtlsdr_set_tuner_gain.argtypes=[ctypes.c_void_p,ctypes.c_int]
        self.lib.rtlsdr_get_tuner_gains.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_int)]
        self.lib.rtlsdr_reset_buffer.argtypes=[ctypes.c_void_p]
        self.lib.rtlsdr_read_sync.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ctypes.c_int,ctypes.POINTER(ctypes.c_int)]
        rc=self.lib.rtlsdr_open(ctypes.byref(self.dev),int(index))
        if rc != 0: raise RuntimeError(f'rtlsdr_open failed {rc}')
        self.sample_rate=None; self.gain=None; self.ppm=None
        self.rate_changed=False

    def _check(self, rc, what):
        if rc != 0: raise RuntimeError(f'{what} failed {rc}')

    def configure(self, sr, ppm, gain):
        self.rate_changed=False
        if self.sample_rate != int(sr):
            self._check(self.lib.rtlsdr_set_sample_rate(self.dev,int(sr)),'set_sample_rate')
            self.sample_rate=int(sr); self.rate_changed=True
        if self.ppm != int(ppm):
            # Some RTL-SDR Blog V4 builds return -2 for an explicit zero PPM
            # request. Zero already means no correction, so skip that call.
            if int(ppm) != 0:
                self._check(self.lib.rtlsdr_set_freq_correction(self.dev,int(ppm)),'set_freq_correction')
            self.ppm=int(ppm)
        wanted='auto' if gain=='auto' else float(gain)
        if self.gain != wanted:
            if wanted == 'auto':
                self._check(self.lib.rtlsdr_set_tuner_gain_mode(self.dev,0),'gain_auto')
            else:
                self._check(self.lib.rtlsdr_set_tuner_gain_mode(self.dev,1),'gain_manual')
                n=self.lib.rtlsdr_get_tuner_gains(self.dev,None)
                tenth=int(round(float(wanted)*10))
                if n>0:
                    arr=(ctypes.c_int*n)()
                    self.lib.rtlsdr_get_tuner_gains(self.dev,arr)
                    tenth=min(arr,key=lambda x:abs(int(x)-tenth))
                self._check(self.lib.rtlsdr_set_tuner_gain(self.dev,int(tenth)),'set_tuner_gain')
            self.gain=wanted

    def tune(self, center):
        self._check(self.lib.rtlsdr_set_center_freq(self.dev,int(center)),'set_center_freq')

    def reset(self):
        self._check(self.lib.rtlsdr_reset_buffer(self.dev),'reset_buffer')

    def read_complex(self, count, chunk=131072, abort=None):
        """Read ``count`` complex samples in USB-sized chunks.

        A v8 verification dwell is a quarter of a million samples, far more
        than one bulk transfer should carry.  Chunking also gives the scan
        thread somewhere to notice a shutdown request, instead of sitting
        inside one very long blocking read.
        """
        remaining=int(count)
        parts=[]
        buf=(ctypes.c_ubyte*(int(chunk)*2))()
        got=ctypes.c_int()
        while remaining>0:
            if abort is not None and abort():
                raise RuntimeError('capture aborted')
            take=min(remaining,int(chunk))
            nbytes=take*2
            self._check(self.lib.rtlsdr_read_sync(self.dev,buf,nbytes,ctypes.byref(got)),'read_sync')
            if got.value < nbytes:
                raise RuntimeError(f'short read {got.value}/{nbytes}')
            raw=np.ctypeslib.as_array(buf)[:nbytes].astype(np.float32)
            parts.append(((raw[0::2]-127.5)+1j*(raw[1::2]-127.5)).astype(np.complex64))
            remaining-=take
        return parts[0] if len(parts)==1 else np.concatenate(parts)

    def close(self):
        if self.dev:
            try: self.lib.rtlsdr_close(self.dev)
            finally: self.dev=None


class SDRBackend:
    """Passive C2000 activity monitor. No identity, content or distance."""

    def __init__(self,cfg):
        self.cfg=cfg; self.lock=threading.Lock(); self.running=False; self.thread=None
        self.status='STARTING'; self.error=''
        self.peaks=[]; self.mobile_peaks=[]; self.site_peaks=[]
        self.mobile_level=0.; self.site_level=0.
        self.activity_confidence=0.; self.mobile_confirmed=False
        self.alert_provisional=False; self.provisional_hit_at=0.
        self.spectrum_freqs=np.array([],dtype=np.float64)
        self.spectrum_db=np.array([],dtype=np.float32)
        self.noise_floor_db=-100.; self.last_update=0.; self.demo_active=False
        self._demo_forced=bool(cfg.get('demo_mode',False))
        # Set by set_demo, acted on by the scan thread: see _reopen_sdr.
        self._sdr_reopen=False
        self.driver_path=''
        self.driver_knows_model=False
        # See _check_capture.
        self._last_capture_sig=None
        self.stuck_captures=0
        # Alternates candidate work with the band pass; see _site_work.
        self._priority_turn=0
        self.last_good_scan=0.; self.scan_failures=0; self.last_usb_reset=0.
        self._usb_resets=0; self._usb_backoff=0.
        self._power_checked=0.; self._power_flag=''
        self._power_history=''; self._power_detail=''
        self.sdr=None; self.sdr_path='UNOPENED'
        self.last_cycle_ms=0.; self.last_survey_ms=0.; self.last_dwell_ms=0.
        self.last_verify_ms=0.; self.last_capture_ms=0.; self.last_scan_windows=0

        self.sites=SiteRegistry(cfg)
        self.alarm=UplinkAlarm(cfg)
        # The radio's share of the time, learned from the supply; next to the
        # site state so a test run never touches the unit's own.
        self.ladder=PowerLadder(cfg,self.sites._path().with_name('power-state.json'))
        self._power_bits=None; self._power_pending=[]
        self._uv_alarm={}; self._uv_alarm_last=None; self._uv_alarm_at=0.
        self._uv_events=0; self._uv_counted_at=0.; self._soc_temp=None
        self._power_log_at=0.; self._power_hb_at=0.; self._sdr_lost_at=0.
        # What the ADC is seeing, per band, and how much gain overload has
        # taken off; see _watch_overload.
        self.adc_rms=0.; self.adc_clip=0.
        # Set while the radio is not reading. The panel's SPI traffic is
        # noise in the band, so the UI waits on this before sending a frame;
        # see App._show.
        self.capture_idle=threading.Event(); self.capture_idle.set()
        self._gain_backoff={'up':0.,'down':0.}; self._gain_clean_since={'up':0.,'down':0.}
        self._alert_logged='CLEAR'
        self.detector_state='SEARCHING'
        self.survey_shortlist=[]
        self._survey_at=0.; self._survey_idx=0; self._site_maint_idx=0
        self._site_queue=[]; self._sweep_cursor=0.; self._alt_cycle=False
        self._survey_scores=[]
        self._pass_best=None; self._pass_started=0.; self._pass_index=0
        self._pass_channels=0; self._pass_ok=0; self._pass_fails={}
        self.last_pass_s=0.
        self._site_verify_at=0.; self._watch_idx=0; self._display_cycle=0
        # Uplink watch: _watch_idx walks the whole 380-385 MHz band,
        # _partner_idx the duplex partners of the locked carriers, and
        # _watch_turn alternates between the two.
        self._partner_idx=0; self._watch_turn=0; self._track_run=0
        self._uplink_queue=[]; self._uplink_sweeps=0
        self._pump=None; self._prefetch=None; self._site_share=0
        self._prefetch_hits=0; self._prefetch_misses=0
        self._radio_s=0.0; self._radio_epoch=time.time()
        self.last_screened=0
        self._band_cache_key=None; self._band_cache=[]
        # Uplink channels that just verified, and how many dwells are left to
        # spend confirming them; see _watch_work.
        self._follow=[]; self._follow_left=0; self._follow_until=0.0
        self.last_phy=[]
        self.dwell_centre_hz=0.; self.dwell_channels=[]
        self.last_dwell_role=''
        self.last_iq=None; self.last_iq_meta={}

    # -- lifecycle ---------------------------------------------------------
    def set_demo(self,v):
        v=bool(v)
        with self.lock:
            if v==self._demo_forced:
                return
            self._demo_forced=v; self.cfg['demo_mode']=v
            # Demo must not hold the radio while it is not reading it, and
            # coming back out of demo must not inherit the failure counters
            # and back-off of whatever went wrong before it was switched on.
            # Both are the scan thread's job: closing a librtlsdr handle from
            # the UI thread while that thread may be inside rtlsdr_read_sync()
            # is the race stop() already goes out of its way to avoid, and it
            # can wedge the V4 on the bus. So ask, do not do.
            self._sdr_reopen=True
            if not v:
                self.peaks=[]; self.mobile_peaks=[]; self.site_peaks=[]
                self.mobile_level=0.; self.site_level=0.
                self.activity_confidence=0.; self.mobile_confirmed=False
                self.alert_provisional=False
                self.demo_active=False; self.alarm.reset()
                self._follow=[]; self._follow_left=0
                self.detector_state='SEARCHING'; self.last_phy=[]
                self.survey_shortlist=[]; self._survey_at=0.
                self._site_queue=[]; self._sweep_cursor=0.
                self.status='SCANNING'; self.error=''; self.last_update=time.time()

    def start(self):
        if self.running:return
        self.running=True
        self.thread=threading.Thread(target=self._run,daemon=True); self.thread.start()

    def stop(self):
        self.running=False
        t=self.thread
        # Never close a librtlsdr handle from the UI/service thread while the
        # scan thread may still be inside rtlsdr_read_sync(). That race can
        # wedge the RTL-SDR Blog V4 on the USB bus during restart/shutdown.
        if t and t is not threading.current_thread():
            t.join(timeout=max(3.0,float(self.cfg.get('sdr_stop_join_s',8.0))))
        if not t or not t.is_alive():
            self._close_direct_sdr()
        try: self.sites.save()
        except Exception: pass

    def reinit_usb(self):
        """Drop the SDR handle and look for the device again, from scratch.

        The useful moment for this is right after someone has changed
        something physical -- a cable, a port, the supply -- and wants the
        appliance to look again without a reboot. It closes the librtlsdr
        handle, clears the failure counters and back-off that would otherwise
        make the next attempt wait, and resets the device over USB if it is
        actually on the bus. A device that is not enumerated cannot be reset
        by anyone, so that case is reported rather than papered over.
        """
        self._close_direct_sdr()
        self._usb_resets = 0
        self._usb_backoff = 0.
        self.last_usb_reset = 0.
        self._power_checked = 0.
        present = self._sdr_present()
        did_reset = self._recover_sdr_usb() if present else False
        with self.lock:
            self.scan_failures = 0
            self.error = '' if present else 'SDR not on the USB bus'
        return {'present': bool(present), 'reset': bool(did_reset)}

    def _reopen_sdr(self):
        """Start the radio from scratch, on the thread that owns the handle.

        Only ever called from the scan loop. Everything that can make the
        next open fail for a reason that no longer applies is cleared here:
        the handle itself, the USB reset counter and its back-off, and the
        run of failures that decides whether the panel says NO SDR.
        """
        self._close_direct_sdr()
        self._usb_resets=0
        self._usb_backoff=0.
        self.last_usb_reset=0.
        with self.lock:
            self.scan_failures=0
            self.last_good_scan=0.

    def radio_duty(self, now=None):
        """What fraction of recent time the dongle has been streaming."""
        now = time.time() if now is None else float(now)
        elapsed = max(1e-3, now - self._radio_epoch)
        return max(0.0, min(1.0, self._radio_s / elapsed))

    def _duty_limit(self, now):
        """The share of the time the radio may stream, and why.

        This is the knob that decides current draw. An RTL-SDR pulls its
        several hundred milliamps while it is *streaming*, so the honest way to
        spend less is to stream a smaller fraction of the time -- not to hope a
        fixed pause between cycles happens to be enough.

        It became a real number in 0.9.38 because 0.9.37 quietly moved it. With
        the capture on its own thread and a 0.10 s pause the dongle was reading
        about 88% of the time against 37% before, and a field unit dropped it
        off the bus 169 s after boot with the under-voltage flag set.
        """
        if not bool(self.cfg.get('low_power_mode', True)):
            limit = float(self.cfg.get('sdr_duty_max_power', 1.0))
        else:
            # Spend where something is. With nothing heard recently the band
            # is swept at a slower, cooler rate; the moment a track is live
            # the radio is allowed to work, which is the only time the extra
            # current buys anything.
            if self.alarm.tracks.heard(now):
                limit = float(self.cfg.get('sdr_duty_eco', 0.55))
            else:
                limit = float(self.cfg.get('sdr_duty_idle', 0.45))
        # And never more than the supply has shown it can carry. Until 0.10.2
        # this was "0.30 once the since-boot under-voltage bit is set", which
        # never clears -- so one dip pinned the radio there until a reboot,
        # and a unit that had not dipped yet ran flat out until it did. The
        # ladder drops on trouble and climbs back on calm; see power.py.
        limit = min(limit, self.ladder.cap)
        return min(1.0, max(0.05, limit))

    def _low_power_pause(self):
        """Hold the radio to its share of the time, and let the CPU breathe.

        Idling also lets the governor clock back down; without it the detector
        hands a Pi 3 B+ a continuous FFT load. Both matter on a marginal 5 V
        rail, and that rail is what decides whether the RTL-SDR stays on the
        bus at all.
        """
        now = time.time()
        limit = self._duty_limit(now)
        window = max(5.0, float(self.cfg.get('sdr_duty_window_s', 20.0)))
        elapsed = now - self._radio_epoch
        if elapsed > window:
            # Slide the window rather than clearing it, or the duty would
            # restart at zero and the radio would run flat out in bursts.
            self._radio_epoch = now - window * 0.5
            self._radio_s *= 0.5
            elapsed = max(1e-3, now - self._radio_epoch)
        pause = 0.0
        if limit < 1.0 and self._radio_s > 0.0:
            pause = (self._radio_s / limit) - max(1e-3, elapsed)
        floor = max(0.0, float(self.cfg.get('low_power_min_pause_s', 0.0)))
        if bool(self.cfg.get('low_power_mode', True)):
            floor = max(floor, float(self.cfg.get('low_power_locked_pause_s', 0.10)))
        pause = max(floor, min(pause, 3.0))
        if pause <= 0.0:
            return
        end = time.time() + pause
        while self.running and time.time() < end:
            time.sleep(min(0.25, max(0.01, end - time.time())))

    def _run(self):
        if self._pump is None and bool(self.cfg.get('scan_pipeline',True)):
            self._pump=_CapturePump(lambda c,s,n: self._timed_samples(c,s,n))
        try:
            while self.running:
                try:
                    self._power_tick()
                except Exception:
                    pass                 # watching the supply must never stop the scan
                with self.lock:
                    demo=self._demo_forced
                    reopen=self._sdr_reopen
                    self._sdr_reopen=False
                if reopen:
                    self._reopen_sdr()
                if demo:
                    self._demo_once(); continue
                if not self._scan_cycle():
                    if self.cfg.get('auto_demo_if_no_sdr',False): self._demo_once()
                    else: time.sleep(.5)
                self._low_power_pause()
        finally:
            # Let a prefetch finish before anything closes the handle: the
            # capture thread may be inside rtlsdr_read_sync() right now.
            job,self._prefetch=self._prefetch,None
            if job is not None:
                try: self._pump.wait(job,8.0)
                except Exception: pass
            if self._pump is not None:
                self._pump.stop(); self._pump=None
            # Close from the same worker that performs synchronous USB reads.
            self._close_direct_sdr()

    def snapshot(self):
        lim=self._duty_limit(time.time())
        with self.lock:
            return {
                'status':self.status,'error':self.error,
                'detector_state':self.detector_state,
                'peaks':[dict(p) for p in self.peaks],
                'mobile_peaks':[dict(p) for p in self.mobile_peaks],
                'site_peaks':[dict(p) for p in self.site_peaks],
                'mobile_level':float(self.mobile_level),
                'site_level':float(self.site_level),
                'activity_confidence':float(self.activity_confidence),
                'mobile_confirmed':bool(self.mobile_confirmed),
                # One weak hit on a channel no locked site vouches for: shown,
                # with one short beep per hit, not the running alarm.
                'alert_provisional':bool(self.alert_provisional),
                'provisional_hit_at':float(self.provisional_hit_at),
                'freqs':self.spectrum_freqs.copy(),'spectrum':self.spectrum_db.copy(),
                'noise':float(self.noise_floor_db),
                'driver_path':str(self.driver_path),
                'stuck_captures':int(self.stuck_captures),
                'driver_knows_model':bool(self.driver_knows_model),
                'last_update':float(self.last_update),'demo':bool(self.demo_active),
                'network_locked':bool(self.site_peaks),
                'site_locked_count':len(self.site_peaks),
                'site_candidate_count':len(self.sites.candidates()),
                'site_state_loaded':bool(self.sites.loaded_from_disk),
                'watch_freqs':[float(f) for f in self.dwell_channels],
                'dwell_centre_hz':float(self.dwell_centre_hz),
                'dwell_role':str(self.last_dwell_role),
                'survey_shortlist':[float(f) for f in self.survey_shortlist],
                'search_best':dict(self._pass_best) if self._pass_best else {},
                'last_pass_s':float(self.last_pass_s),
                'site_queue_remaining':len(self._site_queue),
                'phy':[dict(p) for p in self.last_phy],
                'confirm_streak':int(self.alarm.streak),
                'clear_streak':0 if self.mobile_confirmed else 1,
                'cycle_ms':float(self.last_cycle_ms),
                'survey_ms':float(self.last_survey_ms),
                'dwell_ms':float(self.last_dwell_ms),
                'verify_ms':float(self.last_verify_ms),
                'capture_ms':float(self.last_capture_ms),
                # Old key names kept so existing debug and recording consumers
                # keep working across the profile change.
                'mobile_scan_ms':float(self.last_dwell_ms),
                'site_scan_ms':float(self.last_survey_ms),
                'scan_windows':int(self.last_scan_windows),
            'radio_duty':float(self.radio_duty()),
            'duty_limit':float(lim),
            'power_cap':float(self.ladder.cap),
            'power_events':int(self._uv_events),
            'power_incidents':int(self.ladder.incidents),
            'power_next_step_s':float(self.ladder.next_step_s(time.time())),
            'power_last_event':str(self.ladder.last_why),
            'soc_temp_c':float(self._soc_temp) if self._soc_temp is not None else -1.0,
            'adc_rms':float(self.adc_rms),'adc_clip':float(self.adc_clip),
            'gain_db':(-1.0 if self.cfg.get('gain',37.2)=='auto'
                       else float(self._gain_for('up'))),
            'pipeline_active':bool(self._pump is not None and lim>=float(
                self.cfg.get('scan_pipeline_min_duty',0.40))),
            'prefetch_hits':int(self._prefetch_hits),
            'prefetch_misses':int(self._prefetch_misses),
                'sdr_path':str(self.sdr_path),
                'power_warning':str(self._power_flag),
                'power_history':str(self._power_history),
                'power_detail':str(self._power_detail),
            }

    # -- SDR plumbing ------------------------------------------------------
    def _sdr_present(self):
        """Is the RTL-SDR actually enumerated on the USB bus right now?"""
        try:
            for vid in Path('/sys/bus/usb/devices').glob('*/idVendor'):
                if vid.read_text().strip().lower() != '0bda':
                    continue
                pid = vid.parent / 'idProduct'
                if pid.exists() and pid.read_text().strip().lower() == '2838':
                    return True
        except Exception:
            # If the USB tree cannot be read, do not let this block recovery.
            return True
        return False

    def _power_warning(self):
        """Report a Pi supply problem, cached because vcgencmd is not free.

        This exists because a sagging 5 V rail and a broken SDR look identical
        on screen but need completely different fixes. On the reference unit an
        under-voltage dip dropped the dongle off the USB bus entirely, and
        without this the display simply said the SDR was not connected.

        Only bit 0 -- "the 5 V rail is below about 4.63 V *right now*" -- is
        reported as a warning. Bit 16 says it happened at some point since
        boot and never clears again, so driving the display from it meant a
        single dip during power-up left the warning on screen for the rest of
        the session, over the top of a perfectly healthy scan. That history
        is still worth keeping, but it belongs on the debug page.
        """
        now=time.time()
        if now-self._power_checked<10.0:
            return self._power_flag
        self._power_checked=now
        self._power_flag=''; self._power_history=''; self._power_detail=''
        exe=shutil.which('vcgencmd')
        if not exe:
            return ''
        try:
            cp=subprocess.run([exe,'get_throttled'],capture_output=True,
                              text=True,timeout=3)
            word=cp.stdout.strip().split('=')[-1]
            bits=int(word,16)
            if bits & 0x1:
                self._power_flag='UNDER-VOLTAGE'
            if bits & 0x10000:
                self._power_history='UNDER-VOLTAGE EARLIER'
            # What changed since the last look is what the ladder acts on. The
            # first look cannot tell when a set bit happened, only that it was
            # before the radio had a say, so it counts as a dip at power-up;
            # after that, the rail low right now or the since-boot bit newly
            # set are the radio's business.
            prev,self._power_bits=self._power_bits,bits
            if prev is None:
                if bits & 0x10001:
                    self._power_pending.append(('under-voltage before start',False))
            elif bits & 0x1:
                self._power_pending.append(('rail below 4.63 V',True))
            elif (bits & 0x10000) and not (prev & 0x10000):
                self._power_pending.append(('under-voltage since last look',True))
            # A Pi 3 has no ADC on the 5 V input, so the only voltage it can
            # actually measure is the SoC core rail. Report it as what it is
            # rather than dressing it up as a supply reading: the number that
            # matters, 4.63 V, is a threshold the firmware compares against
            # and never hands out.
            core=''
            try:
                cv=subprocess.run([exe,'measure_volts','core'],
                                  capture_output=True,text=True,timeout=3)
                core=cv.stdout.strip().split('=')[-1]
            except Exception:
                pass
            bits_txt='throttled '+word
            self._power_detail=(('core %s, ' % core) if core else '')+bits_txt
        except Exception:
            pass
        return self._power_flag

    def _power_tick(self,now=None):
        """Watch the supply all the time, and move the ladder on what it shows.

        Until 0.10.2 the rail was only looked at after the dongle had already
        gone -- the one moment looking no longer helps. Now it is read on every
        pass round the scan loop: the kernel's own under-voltage alarm every
        couple of seconds (a file read) and ``vcgencmd`` every ten (a
        process). Anything new steps the ladder down, and calm listening steps
        it back up.
        """
        now=time.time() if now is None else float(now)
        in_use=self._duty_limit(now)
        self._power_warning()
        if now-self._uv_alarm_at>=max(0.5,float(self.cfg.get('power_poll_s',2.0))):
            self._uv_alarm_at=now
            self._soc_temp=read_soc_temp()
            alarm=read_uv_alarm(self._uv_alarm)
            if alarm is not None:
                if self._uv_alarm_last is None:
                    if alarm:
                        self._power_pending.append(('under-voltage before start',False))
                elif alarm and not self._uv_alarm_last:
                    self._power_pending.append(('under-voltage (kernel alarm)',True))
                self._uv_alarm_last=alarm
        pending,self._power_pending=self._power_pending,[]
        for why,radio in pending:
            # The kernel alarm and vcgencmd usually both see the same dip.
            if now-self._uv_counted_at>=15.0:
                self._uv_events+=1; self._uv_counted_at=now
            if radio:
                new=self.ladder.event(now,why,in_use=in_use)
            else:
                new=self.ladder.boot_dip(now,why)
            if new:
                self._power_log(now,'DROP %s at %d%% -> cap %d%%'%(
                    why,round(in_use*100),round(self.ladder.cap*100)))
            elif radio:
                self._power_log(now,'%s (same incident)'%why)
        live=bool(self.status=='LIVE' and self.last_good_scan
                  and now-self.last_good_scan<10.0)
        before=self.ladder.cap
        if self.ladder.tick(now,live):
            self._power_log(now,'STEP UP %d%% -> %d%% after %d min without trouble'%(
                round(before*100),round(self.ladder.cap*100),
                round(self.ladder._step_s()/60.0)))
        # On its own clock. It used to share one with every other line, so a
        # unit that logged a dip every twenty seconds never wrote a minute
        # line at all -- and that is the unit whose duty, gain and
        # temperature are most worth having.
        if now-self._power_hb_at>=max(10.0,float(self.cfg.get('power_log_heartbeat_s',60.0))):
            self._power_hb_at=now
            temp=('%.1fC'%self._soc_temp) if self._soc_temp is not None else '?'
            self._power_log(now,'HB cap=%d%% limit=%d%% duty=%d%% pipe=%s temp=%s '
                            'uv=%d sdr=%s bus=%s next=%ds gain=%s clip=%.1f%% %s'%(
                round(self.ladder.cap*100),round(in_use*100),
                round(self.radio_duty(now)*100),
                'on' if self._pipeline_on(now) else 'off',temp,self._uv_events,
                str(self.status).replace(' ','_'),
                'yes' if self._sdr_present() else 'no',
                round(self.ladder.next_step_s(now)),
                self._gain_text(),100.0*self.adc_clip,
                self._power_detail or '-'))

    def _power_log(self,now,text):
        """One line per supply event, per ladder step and per minute.

        Next to search.log, and for the question the field has so far not
        been able to answer: when the dongle went, what had the rail and the
        radio been doing just before? A sag, a dongle that overheats and a
        cable that works loose all look the same on the screen -- "NO SDR" --
        and each needs a different fix.
        """
        self._power_log_at=float(now)
        try:
            path=self.sites._path().with_name('power.log')
            path.parent.mkdir(parents=True,exist_ok=True)
            if path.exists() and path.stat().st_size>262144:
                keep=path.read_text().splitlines()[-1500:]
                path.write_text('\n'.join(keep)+'\n')
            up=''
            try:
                up=' up=%ds'%int(float(Path('/proc/uptime').read_text().split()[0]))
            except Exception:
                pass
            with path.open('a') as f:
                f.write('%s%s %s\n'%(time.strftime('%Y-%m-%dT%H:%M:%S',
                                                     time.localtime(now)),up,text))
        except Exception:
            pass

    def _log_hits(self,now,verified,confirmed):
        """One line per C2000 transmission heard, and per change of the alert.

        Until 0.10.4 nothing on the unit recorded what it had heard. After a
        drive there was the screen someone may or may not have been looking
        at, and a recording if they had thought to start one -- so "it did
        not go off next to that car" could not be told apart from "that car
        was not transmitting". hits.log sits next to search.log and answers
        it: every verified uplink burst with its channel, level and length,
        and each time the alert rose, strengthened or cleared.
        """
        state=('CLEAR' if not confirmed
               else 'PROVISIONAL' if self.alarm.provisional else 'ALARM')
        lines=[]
        for r in verified:
            tr=self.alarm.tracks.get(r.freq_hz,now,create=False)
            lines.append('HIT CH %d %.4f MHz %.1f dB %.0f ms x%d duty %.2f %s%s seen=%d'%(
                carrier_number(r.freq_hz,self.cfg),float(r.freq_hz)/1e6,float(r.snr_db),
                float(r.burst_ms_median),int(r.burst_count),float(r.duty),
                'partner' if (tr is not None and tr.trusted) else 'band',
                ' weak' if getattr(r,'shape_waived',False) else '',
                len(tr.hit_times) if tr is not None else 0))
        if state!=self._alert_logged:
            lines.append('ALERT %s -> %s'%(self._alert_logged,state))
            self._alert_logged=state
        if not lines:
            return
        try:
            path=self.sites._path().with_name('hits.log')
            path.parent.mkdir(parents=True,exist_ok=True)
            if path.exists() and path.stat().st_size>262144:
                keep=path.read_text().splitlines()[-1500:]
                path.write_text('\n'.join(keep)+'\n')
            stamp=time.strftime('%Y-%m-%dT%H:%M:%S',time.localtime(now))
            with path.open('a') as f:
                for line in lines:
                    f.write('%s %s\n'%(stamp,line))
        except Exception:
            pass

    def _recover_sdr_usb(self):
        """Force-re-enumerate a wedged RTL-SDR -- and only a wedged one.

        A USB reset is a blunt instrument, and using it as a general-purpose
        error response makes things worse. Two rules follow from watching it
        misfire on real hardware:

        Never reset a device that is not on the bus. When ``rtlsdr_open``
        fails there is nothing to reset, and hammering the port every few
        seconds stops a device that is trying to re-enumerate from ever
        finishing. That is how a momentary supply dip turned into a dongle
        that stayed gone until the Pi was rebooted.

        Back off, and give up. Repeated resets that do not help are not worth
        the disruption they cause; the counter clears as soon as a scan
        succeeds again.
        """
        now=time.time()
        if now-self.last_usb_reset < max(5.0,self._usb_backoff):
            return False
        if not self._sdr_present():
            # Absent, not wedged. Wait for it to come back on its own.
            self.last_usb_reset=now
            return False
        if self._usb_resets >= max(1,int(self.cfg.get('usb_reset_max_attempts',3))):
            return False
        self.last_usb_reset=now
        self._usb_resets+=1
        self._usb_backoff=min(120.0,15.0*(2**(self._usb_resets-1)))
        self._close_direct_sdr()
        exe=shutil.which('usbreset')
        if not exe: return False
        try:
            cp=subprocess.run([exe,'0bda:2838'],capture_output=True,text=True,timeout=6)
            if cp.returncode==0:
                time.sleep(1.5); return True
        except Exception: pass
        return False

    def _close_direct_sdr(self):
        dev=self.sdr
        self.sdr=None; self.sdr_path='UNOPENED'
        if dev is not None:
            try: dev.close()
            except Exception: pass

    def _check_capture(self,iq):
        """Refuse a capture that is a copy of the previous one.

        A dongle can stop streaming and keep handing back the same buffer,
        however it is retuned. Every channel of every dwell is then analysed
        from identical samples and returns identical numbers -- recorded in
        the field on 11 September, next to an undercover police car, as

            snr 34.3  bw 32344  bnd -13.4  ctr 10039   on 380.04, 380.74,
            381.19, 381.34, 381.84 MHz and on the downlink, for six minutes

        with zero downlink verifications, while the panel went on reporting a
        live, locked network. A receiver in that state cannot detect anything,
        and the one thing it must not do is look as though it can.

        Live air is noise-limited: two captures of it never agree byte for
        byte, on the same frequency or any other, so an exact repeat is proof
        the samples are not new. No threshold to tune, so no false alarm to
        worry about.
        """
        sig=hash(np.ascontiguousarray(iq[::991]).tobytes())
        if sig==self._last_capture_sig:
            self.stuck_captures+=1
            raise RuntimeError('capture stuck: identical to the previous dwell')
        self._last_capture_sig=sig

    def _samples(self,center,sr,count):
        """Tune and read, settling for the PLL and any sample-rate change."""
        try:
            if self.sdr is None:
                self.sdr=_PersistentRTL(int(self.cfg.get('sdr_device_index',0)))
                self.sdr_path='CTYPES PERSISTENT'
                # Which librtlsdr actually got loaded is not a detail: a build
                # that does not know the dongle reports a silent, empty band.
                self.driver_path=str(getattr(self.sdr,'lib_path',''))
                self.driver_knows_model=bool(
                    getattr(self.sdr,'lib_knows_model',False))
            self.sdr.configure(int(sr),int(self.cfg.get('ppm',0)),
                               self._gain_for(self._band_of(center)))
            self.sdr.tune(int(center))
            self.sdr.reset()
            # A sample-rate change reprograms the tuner's IF filter as well as
            # the decimator, so it needs noticeably longer to settle than a
            # plain retune. Reading unsettled samples into a 0.9 s dwell would
            # corrupt the very timing measurements the dwell exists for.
            settle=0.030 if self.sdr.rate_changed else 0.006
            self.capture_idle.clear()
            try:
                self.sdr.read_complex(max(4096,int(sr*settle)),
                                      abort=lambda: not self.running)
                iq=self.sdr.read_complex(int(count),abort=lambda: not self.running)
            finally:
                self.capture_idle.set()
            self._check_capture(iq)
            return iq
        except Exception as e:
            self._close_direct_sdr()
            raise RuntimeError('librtlsdr read failed: '+str(e))

    @staticmethod
    def _band_of(centre):
        """Uplink or downlink half of the C2000 band, for the gain."""
        return 'down' if float(centre)>=387.5e6 else 'up'

    def _gain_for(self,band):
        """The tuner gain for this band: the configured one, less any back-off."""
        gain=self.cfg.get('gain',37.2)
        if gain=='auto':
            return 'auto'
        return max(0.0,float(gain)-float(self._gain_backoff.get(band,0.)))

    def _gain_text(self):
        """Both halves' gain for the log, e.g. ``37.2`` or ``33.2/37.2``."""
        up,down=self._gain_for('up'),self._gain_for('down')
        if up=='auto':
            return 'auto'
        return ('%.1f'%up) if up==down else ('%.1f/%.1f'%(up,down))

    def _watch_overload(self,iq,band,now=None):
        """Keep the 8-bit ADC out of clipping, per band.

        The gain was "auto" until 0.10.4, which hands it to the tuner's own
        AGC. Measured on both reference dongles (R820T and R828D), that fills
        the ADC with noise alone: in the empty uplink band 17% of the samples
        sat on the rails, and on the downlink 12-27%. A fixed 37.2 dB reads
        the same carriers 1-1.5 dB better with nothing clipped, and leaves
        about 15 dB of room above the noise, so a transmitter close by still
        measures stronger than one further off instead of both reading the
        same saturated level.

        A fixed gain needs a guard for the place where it is too much -- next
        to a mast, or a handset keyed up at arm's length. When more than
        gain_clip_limit of a capture clips, that band's gain steps down; when
        it has been clean for gain_recover_s it steps back. The two halves of
        the band are kept apart, because the downlink carries strong
        continuous carriers and must not cost the uplink its sensitivity.
        """
        now=time.time() if now is None else float(now)
        sub=iq[::16]
        if not len(sub):
            return
        self.adc_rms=float(np.sqrt(np.mean(np.abs(sub)**2)))
        self.adc_clip=float(np.mean((np.abs(sub.real)>=126.5)|(np.abs(sub.imag)>=126.5)))
        if self.cfg.get('gain',37.2)=='auto':
            return
        limit=float(self.cfg.get('gain_clip_limit',0.05))
        step=max(0.5,float(self.cfg.get('gain_backoff_step_db',4.0)))
        most=max(0.0,float(self.cfg.get('gain_backoff_max_db',24.0)))
        before=self._gain_for(band)
        if self.adc_clip>limit:
            self._gain_backoff[band]=min(most,self._gain_backoff[band]+step)
            self._gain_clean_since[band]=now
        elif self._gain_backoff[band]>0.0:
            if self.adc_clip>limit*0.25:
                self._gain_clean_since[band]=now
            elif now-self._gain_clean_since[band]>=float(self.cfg.get('gain_recover_s',20.0)):
                self._gain_backoff[band]=max(0.0,self._gain_backoff[band]-step)
                self._gain_clean_since[band]=now
        after=self._gain_for(band)
        if after!=before:
            # Said out loud, with what was seen: the first unit to run this
            # stepped down twice in its first minute and there was no way to
            # tell afterwards whether that was a transmitter close by or a
            # mistake.
            self._power_log(now,'GAIN %slink %.1f -> %.1f dB (clip %.1f%%, rms %.0f)'%(
                band,before,after,100.0*self.adc_clip,self.adc_rms))

    def _timed_samples(self,centre,sr,count):
        """``_samples`` with the time the dongle spent streaming accounted for.

        Every read goes through here, from the capture thread and from the
        direct path alike, because the duty limit is only honest if it counts
        all of them.
        """
        t0=time.perf_counter()
        try:
            iq=self._samples(centre,sr,count)
            try:
                self._watch_overload(iq,self._band_of(centre))
            except Exception:
                pass                     # a level check must never cost a capture
            return iq
        finally:
            self._radio_s+=time.perf_counter()-t0

    def _capture(self,centre,sr,count):
        """Read one capture, through the pump when it is running."""
        if self._pump is None:
            return self._timed_samples(centre,sr,count)
        budget=8.0+3.0*float(count)/max(1.0,float(sr))
        return self._pump.wait(self._pump.submit(centre,sr,count),budget)

    def _capture_dwell(self,centre,sr,count):
        """The dwell capture, taking the prefetched one when it fits.

        A prefetch that no longer matches the plan is still waited for before
        anything else is asked of the radio -- the handle is single threaded,
        and a discarded capture is cheaper than a race.
        """
        job=self._prefetch; self._prefetch=None
        if job is not None:
            key=(int(round(float(centre))),int(sr),int(count))
            try:
                iq=self._pump.wait(job,8.0+3.0*float(count)/max(1.0,float(sr)))
            except Exception:
                iq=None                      # a fresh read will say what broke
            if iq is not None and job['key']==key:
                self._prefetch_hits+=1
                return iq
            self._prefetch_misses+=1
        return self._capture(centre,sr,count)

    def _pipeline_on(self,now):
        """Is overlapping capture with analysis worth its peak current?

        The pipeline exists to reach a high radio share: it streams the next
        dwell while this one is analysed. That is also the moment the unit
        draws the most -- dongle streaming, USB interrupts and a core doing
        FFTs, all at once. One thread on a Pi 3 B+ already streams roughly a
        third of the time (a 0.52 s capture against a little under a second
        of work), so at the steps the power ladder falls back to, the overlap
        buys no more listening -- only a higher peak on a rail that has just
        sagged.
        """
        if self._pump is None:
            return False
        return self._duty_limit(now) >= float(self.cfg.get('scan_pipeline_min_duty',0.40))

    def _prefetch_uplink(self,now):
        """Start the next uplink capture while this cycle is still analysing."""
        if self._pump is None or self._prefetch is not None or not self.running:
            return
        if not self._pipeline_on(now):
            return
        try:
            plan=self._uplink_plan(now)
            if not plan:
                return
            sr=int(self.cfg.get('phy_sample_rate',2016000))
            n=1<<int(self.cfg.get('phy_dwell_log2',20))
            centre,members=plan_dwell(
                plan['targets'],sr,
                max_offset_hz=float(self.cfg.get('phy_max_offset_hz',600000.)),
                spacing_hz=float(self.cfg.get('tetra_channel_spacing_hz',25000.)))
            if centre is None or not members:
                return
            self._prefetch=self._pump.submit(centre,sr,n)
        except Exception:
            self._prefetch=None

    def _capture_spectrum(self,center,sr,n,blocks,percentile=None):
        """Wideband survey capture; returns (freqs, power_db)."""
        t0=time.perf_counter()
        iq=self._capture(center,sr,n*blocks)
        self.last_capture_ms=(time.perf_counter()-t0)*1000.
        rows=min(blocks,len(iq)//n)
        if rows<1: raise RuntimeError('no complete FFT blocks')
        m=np.asarray(iq[:rows*n],dtype=np.complex64).reshape(rows,n).copy()
        m-=np.mean(m,axis=1,keepdims=True)
        win=np.hanning(n).astype(np.float32)
        stack=20*np.log10(np.abs(np.fft.fftshift(np.fft.fft(m*win,axis=1),axes=1))+1e-12)
        psd=np.mean(stack,axis=0) if percentile is None else np.percentile(
            stack,float(percentile),axis=0)
        # Blank the tuner DC spike so it cannot masquerade as a carrier.
        mid=len(psd)//2; lo=max(0,mid-2); hi=min(len(psd),mid+3)
        if lo>0 and hi<len(psd):
            side=np.r_[psd[max(0,lo-8):lo],psd[hi:min(len(psd),hi+8)]]
            psd[lo:hi]=float(np.median(side))
        return np.fft.fftshift(np.fft.fftfreq(n,1./sr))+center,psd

    def _sweep(self,a,b,percentile=None):
        """Sweep a band at the wide sample rate; returns (freqs, power_db)."""
        sr=int(self.cfg.get('sample_rate',2048000)); n=int(self.cfg.get('fft_size',1024))
        ms=float(self.cfg.get('survey_capture_ms',48.0))
        blocks=max(8,int(math.ceil(sr*ms/1000/n)))
        usable=sr*.68/2; step=sr*.68*.9
        fs=[]; ps=[]; c=a+usable
        while True:
            f,p=self._capture_spectrum(c,sr,n,blocks,percentile)
            self.last_scan_windows+=1
            m=(f>=a)&(f<=b)&(np.abs(f-c)<=usable)
            if np.any(m): fs.append(f[m]); ps.append(p[m])
            if c+usable>=b: break
            c+=step
        if not fs: return np.array([]),np.array([])
        f=np.concatenate(fs); p=np.concatenate(ps)
        o=np.argsort(f)
        return f[o],p[o]

    # -- stage 1: find downlink carriers worth verifying -------------------
    def _downlink_raster(self):
        """Every ETSI raster channel in the downlink band, low to high."""
        a=float(self.cfg.get('site_band_start_hz',390e6))
        b=float(self.cfg.get('site_band_end_hz',395e6))
        step=max(1.,float(self.cfg.get('tetra_channel_spacing_hz',25000.)))
        off=float(self.cfg.get('tetra_raster_offset_hz',12500.))
        return [float(x) for x in np.arange(a+off,b,step)]

    def _survey_downlink(self):
        """Rank downlink raster channels by how much they look like a carrier.

        Ranking by raw power alone does not survive contact with real
        hardware: an RTL-SDR's internal spur comb is stronger than a distant
        base station, so the strongest channels in this band are routinely
        the receiver's own artefacts.  Measured on the reference unit, the
        top ten channels sat on an 800 kHz grid -- a comb, not a network.

        So the score also asks whether the energy is *shaped* like a 25 kHz
        TETRA carrier: flat right across the channel.  A spur is a narrow
        line and is punished for it.  This only reorders work, it can never
        admit anything: every channel still has to pass the full waveform
        test before it counts.
        """
        a=float(self.cfg.get('site_band_start_hz',390e6))
        b=float(self.cfg.get('site_band_end_hz',395e6))
        f,p=self._sweep(a,b)
        if not len(f): return []
        half=float(self.cfg.get('tetra_channel_half_width_hz',9000.))
        rows=[]
        for ch in self._downlink_raster():
            m=np.abs(f-ch)<=half
            if int(np.count_nonzero(m))<3: continue
            seg=p[m]
            level=float(np.median(seg))
            # A flat 25 kHz carrier barely differs from its own median; a
            # narrow spur towers over it.
            peak=float(np.max(seg))-level
            rows.append((ch,level,peak))
        if not rows: return []
        floor=float(np.percentile(np.array([r[1] for r in rows]),30))
        w=float(self.cfg.get('survey_flatness_weight',0.5))
        tol=float(self.cfg.get('survey_flatness_tolerance_db',6.0))
        minsnr=float(self.cfg.get('survey_min_snr_db',6.0))
        scored=[]
        for ch,level,peak in rows:
            snr=level-floor
            if snr<minsnr: continue
            scored.append((ch,snr-w*max(0.,peak-tol)))
        scored.sort(key=lambda x:x[1],reverse=True)
        # Kept whole. The shortlist below is only what the UI shows; the
        # verification queue is built from the full ranking, so a carrier the
        # survey rates 20th is reached on the fifth dwell instead of waiting
        # out the systematic remainder of the band.
        self._survey_scores=[(float(ch),float(sc)) for ch,sc in scored]
        limit=max(1,int(self.cfg.get('survey_max_candidates',12)))
        return [ch for ch,_ in scored[:limit]]

    def _refill_site_queue(self,now):
        """Rebuild the downlink verification queue for one full band pass.

        Every channel the survey could score goes first, strongest-looking
        first, and then *every* remaining raster channel.  Both halves matter.
        Ordering by survey score is what makes acquisition quick: one dwell
        covers four channels and takes about 1.1 s, so a 200-channel band is
        68 s end to end and the position of a real carrier in the queue is
        the whole time-to-lock budget.  Keeping the remainder is what makes
        it safe: on the reference unit the survey's top twelve were entirely
        spur-comb teeth, and an earlier design that queued only those never
        handed a genuine but weaker C2000 carrier to the verifier at all.

        A full pass is 50 dwells, about 70 seconds, and it only runs while no
        network is locked.
        """
        t0=time.perf_counter()
        ranked=self._survey_downlink()
        self.last_survey_ms=(time.perf_counter()-t0)*1000.
        self.survey_shortlist=list(ranked)
        self._log_pass(now)
        scored=[ch for ch,_ in self._survey_scores]
        seen={int(round(x)) for x in scored}
        rest=[x for x in self._downlink_raster() if int(round(x)) not in seen]
        # Continue the systematic pass where the previous one stopped, so
        # repeated passes do not keep re-checking the bottom of the band.
        if self._sweep_cursor:
            after=[x for x in rest if x>self._sweep_cursor]
            rest=after+[x for x in rest if x<=self._sweep_cursor]
        self._site_queue=scored+rest
        self._survey_at=now
        self._pass_best=None; self._pass_started=now; self._pass_index+=1
        self._pass_channels=0; self._pass_ok=0; self._pass_fails={}

    def _note_pass_best(self,results):
        """Keep the most promising channel seen during this band pass.

        Without this a unit that searches for half an hour can say only that
        it found nothing, which is indistinguishable between "no C2000 here",
        "antenna fell off" and "one acceptance limit is too tight". The best
        channel and the check it failed on separate those three.
        """
        for r in results:
            self._pass_channels+=1
            if r.ok:
                self._pass_ok+=1
            else:
                for name in r.failed():
                    self._pass_fails[name]=self._pass_fails.get(name,0)+1
            if self._pass_best is None or r.snr_db>self._pass_best['snr_db']:
                self._pass_best={'freq_hz':float(r.freq_hz),
                                 'snr_db':float(r.snr_db),
                                 'ok':bool(r.ok),
                                 'fail':','.join(r.failed())}

    def _log_pass(self,now):
        """Append one line per completed band pass to the search log."""
        best=self._pass_best
        if not best or not self._pass_started:
            return
        # Measured, not the figure in the README: what a pass really costs on
        # this Pi in the mode it is actually running.
        self.last_pass_s=float(now-self._pass_started)
        try:
            # Next to the site state, so it follows RFEYE_SITE_STATE and a
            # test run never appends to the unit's own log.
            path=self.sites._path().with_name('search.log')
            path.parent.mkdir(parents=True,exist_ok=True)
            if path.exists() and path.stat().st_size>262144:
                keep=path.read_text().splitlines()[-800:]
                path.write_text('\n'.join(keep)+'\n')
            # Enough to tell, months later and without the unit in front of
            # you, whether a change to the algorithm helped or hurt: how long
            # the pass took, how much of the band it actually got through, how
            # many channels passed the full waveform test, and what the rest
            # fell over on.
            common=''
            if self._pass_fails:
                name,count=max(self._pass_fails.items(),key=lambda kv:kv[1])
                common=' mostly=%s(%d)'%(name,count)
            line=('%s pass=%d %.0fs ch=%d phy=%d locked=%d cand=%d '
                  'best=%.4fMHz snr=%.1f %s%s\n'%(
                time.strftime('%Y-%m-%dT%H:%M:%S',time.localtime(now)),
                self._pass_index,now-self._pass_started,
                self._pass_channels,self._pass_ok,
                len(self.sites.locked(now)),len(self.sites.candidates(now)),
                best['freq_hz']/1e6,best['snr_db'],
                'TETRA' if best['ok'] else ('fail:'+(best['fail'] or '?')),
                common))
            with path.open('a') as fh:
                fh.write(line)
        except Exception:
            pass

    # -- stage 2: verify a group of channels in one narrowband dwell -------
    def _verify(self,freqs,role):
        """Dwell on ``freqs`` and run the full TETRA test on each.

        All channels of one dwell share a single capture and a single forward
        FFT, so watching a whole site's uplink list costs barely more than
        watching one channel of it.
        """
        sr=int(self.cfg.get('phy_sample_rate',2016000))
        n=1<<int(self.cfg.get('phy_dwell_log2',20))
        centre,members=plan_dwell(
            freqs,sr,
            max_offset_hz=float(self.cfg.get('phy_max_offset_hz',600000.)),
            spacing_hz=float(self.cfg.get('tetra_channel_spacing_hz',25000.)))
        if centre is None or not members:
            return []
        t0=time.perf_counter()
        iq=self._capture_dwell(centre,sr,n)
        self.last_dwell_ms=(time.perf_counter()-t0)*1000.
        self.last_capture_ms=self.last_dwell_ms
        self.last_scan_windows+=1

        t1=time.perf_counter()
        ch=Channelizer(iq,sr)
        out=[]
        # Cheap first, heavy after. A swept band is nearly all empty -- on the
        # field unit 205 of 208 channels were flat noise -- and every one of
        # them was paid for at full price. One prefix sum over the capture
        # gives every channel's level at once; only what clears the floor
        # faces the waveform test. The screen reads high by construction, so
        # it can drop a channel the real test would have dropped and never one
        # it would have kept; measured against it, -0.6 to +0.5 dB.
        screened=set()
        if bool(self.cfg.get('phy_screen',True)):
            try:
                sensitive=(role=='UPLINK'
                           and bool(self.cfg.get('uplink_sensitive',False)))
                pct=(float(self.cfg.get('phy_uplink_sensitive_percentile',100.))
                     if sensitive else 92.0)
                prep=ch.shape_prepared(percentile=pct)
                # The same floor the waveform test applies: lower for a
                # sensitive uplink since 0.10.3, where a weak burst is judged
                # on its modulation rather than its shape.
                lowest=(float(self.cfg.get('phy_uplink_min_snr_db',5.0)) if sensitive
                        else float(self.cfg.get('phy_min_snr_db',8.0)))
                floor=lowest-max(0.,float(self.cfg.get('phy_screen_margin_db',2.0)))
                levels=tetra_phy.screen_levels(prep,[o for _,o in members])
                for freq,offset in members:
                    if float(levels.get(float(offset),99.0))<floor:
                        r=PhyResult(freq_hz=float(freq),role=role)
                        r.snr_db=float(levels.get(float(offset),0.0))
                        r.checks={'snr':False}
                        r.reason='FAIL:snr'
                        r.screened=True
                        screened.add(int(round(float(freq))))
                        out.append(r)
            except Exception:
                screened=set(); out=[]
        self.last_screened=len(screened)
        for freq,offset in members:
            if int(round(float(freq))) in screened:
                continue
            try:
                out.append(tetra_phy.analyse(
                    ch,offset,role=role,limits=self.cfg,freq_hz=freq,
                    decim=int(self.cfg.get('phy_decimation',8)),
                    timing_phases=int(self.cfg.get('phy_timing_phases',8))))
            except Exception as e:
                r=PhyResult(freq_hz=float(freq),role=role)
                r.reason='ERROR:'+str(e)[:60]
                out.append(r)
        self.last_verify_ms=(time.perf_counter()-t1)*1000.
        self.dwell_centre_hz=float(centre)
        self.dwell_channels=[f for f,_ in members]
        self.last_dwell_role=role
        if bool(self.cfg.get('keep_last_iq',True)):
            # Held so a confirmed alert can be written out as raw IQ and
            # re-checked offline. This is the evidence trail that recordings
            # of derived statistics could never provide.
            self.last_iq=iq
            self.last_iq_meta={'centre_hz':float(centre),'sample_rate':int(sr),
                               'samples':int(len(iq)),'role':role,
                               'gain':str(self._gain_for(self._band_of(centre))),
                               'captured_at':time.time()}
        return out

    def _raster(self,freq,band_start):
        return float(raster_snap(
            freq,band_start,
            float(self.cfg.get('tetra_raster_offset_hz',12500.)),
            float(self.cfg.get('tetra_channel_spacing_hz',25000.))))

    # -- orchestration -----------------------------------------------------
    def _reverify_interval(self,locked):
        """How often a locked carrier is re-tested.

        Every locked carrier has to come round again well inside
        site_lock_stale_s or it ages out while still perfectly healthy.
        Rotating one carrier per tick at a fixed 60 s meant ten carriers took
        600 s for a full turn -- exactly the stale limit, before any scan work
        or low-power pause is counted. So the tick shortens as more carriers
        are found. Both the caller that decides whether to run site work and
        the site work itself read this, or the two disagree and the shorter
        interval never actually happens.
        """
        base=max(0.,float(self.cfg.get('site_reverify_s',60.0)))
        if not locked:
            return base
        stale=max(60.,float(self.cfg.get('site_lock_stale_s',600.0)))
        return min(base,max(5.,stale/(2.0*max(1,len(locked)-1))))

    def _site_work(self,now):
        """Acquire a C2000 network lock, or keep an existing one fresh."""
        band=float(self.cfg.get('site_band_start_hz',390e6))
        locked=self.sites.locked(now)

        # Half-verified carriers come first: they already passed the waveform
        # test at least once, so they are the cheapest route to a lock.
        #
        # But a round is exactly one dwell, one ~100 kHz window, so whatever
        # heads this list consumes the entire round. Serving every candidate
        # every round therefore stops the band pass dead as soon as a
        # candidate sits outside the window the queue is working through.
        # Observed on a field unit: two candidates 575 kHz apart, and not one
        # band pass logged in an hour while the unit reported SEARCHING and
        # looked busy. `candidates()` has no age limit, so this never expires
        # on its own.
        #
        # So they alternate with the queue rather than pre-empting it. A
        # candidate is still re-tested every couple of rounds -- a few seconds
        # -- which is far quicker than it needs to be to reach a lock, and the
        # pass keeps moving. With nothing queued they get every round, because
        # then there is nothing to starve.
        candidates=[c['freq_hz'] for c in self.sites.candidates(now)]
        self._priority_turn+=1
        priority=[]
        if candidates and (not self._site_queue or self._priority_turn%2==0):
            # Rotate, so candidates too far apart to share a dwell take turns
            # instead of the first one holding every slot it is offered.
            start=(self._priority_turn//2)%len(candidates)
            priority=candidates[start:]+candidates[:start]

        # Re-proving a locked carrier is on its own timer, not queued behind
        # the band pass. Waiting for the pass to finish meant a locked site
        # went unchecked for the hundreds of rounds a full sweep takes, so a
        # receiver that had stopped hearing anything -- an unplugged antenna,
        # a drive out of coverage -- kept reporting a locked network. The
        # timer keeps it rare enough not to starve the pass, which is what
        # putting it behind the queue was trying to achieve.
        reverify=self._reverify_interval(locked)
        if locked and now-self._site_verify_at>=reverify:
            # Every locked carrier takes its turn, evenly. There used to be a
            # designated "health" carrier that was re-tested on every tick and
            # whose silence condemned the whole site -- which gave one channel
            # a veto over every other, and made itself the health carrier for
            # ever by being the one that got re-tested. A site that was plainly
            # still there came back with nothing locked because of it.
            #
            # Nothing needs designating now: each carrier keeps its own lock
            # and loses it on its own evidence, and _reverify_interval already
            # shortens the tick as more carriers are found so a full turn stays
            # well inside site_lock_stale_s.
            priority.insert(0,locked[self._site_maint_idx%len(locked)]['freq_hz'])
            self._site_maint_idx+=1
            self._site_verify_at=now

        if not self._site_queue:
            # A TETRA site runs several carriers and a vehicle can be keyed up
            # on any of them. Locking the first one and then never sweeping
            # again left the uplink watch list one channel wide for the rest
            # of the session, so a handset on any other carrier of the same
            # site was invisible -- the detector was not deaf, it had simply
            # stopped looking.
            #
            # The refill is on a timer and is deliberately NOT gated behind an
            # empty priority list, in either state. 0.9.11 removed that gate
            # for a locked site and left it standing for an unlocked one, and
            # it is the same trap: one half-verified candidate is enough to
            # keep priority non-empty for ever, and a unit that had heard
            # something once then stopped sweeping the band entirely. Observed
            # on a real unit, 31 minutes without a single band pass while it
            # chased two candidates that could not reach a lock on their own.
            #
            # Nothing is starved by this. The queue rides along behind the
            # priority list, so candidates and due re-proofs are still served
            # first; the refill only decides what gets swept up alongside them.
            if locked:
                interval=max(30.,float(self.cfg.get('site_rescan_s',120.0)))
            else:
                interval=max(5.,float(self.cfg.get('survey_idle_interval_s',15.0)))
            if not self._survey_at or now-self._survey_at>=interval:
                self._refill_site_queue(now)

        # The queue rides along behind the priority list, so a dwell aimed at
        # a candidate also sweeps up whichever queued neighbours fit the same
        # capture for free.
        targets=priority+list(self._site_queue)
        if not targets:
            return []

        seen=set(); ordered=[]
        for x in targets:
            k=int(round(self._raster(x,band)))
            if k not in seen:
                seen.add(k); ordered.append(float(k))

        results=self._verify(ordered,'DOWNLINK')
        self._note_pass_best(results)
        for r in results:
            # A carrier that failed only because there was nothing to hear is
            # idle, not disproved -- traffic carriers are idle most of the time.
            # An idle traffic carrier is "no information"; a channel the
            # cheap screen dropped is not, because nothing looked closely
            # enough to say the carrier was idle rather than gone. Without
            # this a deaf receiver kept its locks: every channel came back as
            # snr-only, which the exemption reads as "quiet, not absent".
            silent=(not r.ok and r.failed()==['snr'] and not r.screened)
            self.sites.observe(r.freq_hz,r.ok,r.quality,now,silent=silent)

        covered={int(round(x)) for x in self.dwell_channels}
        if covered:
            self._sweep_cursor=max(float(x) for x in self.dwell_channels)
        self._site_queue=[x for x in self._site_queue
                          if int(round(x)) not in covered]
        self.survey_shortlist=[x for x in self.survey_shortlist
                               if int(round(x)) not in covered]
        self.sites.save()
        return results

    def _uplink_plan(self,now):
        """What the next uplink dwell would look at, deciding nothing.

        Pulled out of _watch_work so the capture for it can be started while
        the previous dwell is still being analysed. It must not touch state:
        the prefetch runs it, then the dwell itself runs it again and uses the
        waiting capture only if it still plans the same tuner placement.
        """
        band=self._uplink_band_channels()
        # A channel that has just produced verified TETRA joins the fast
        # rotation for a while. Without it, one hit on a channel with no
        # locked partner was usually the only one: the sweep came back about
        # once every fifteen dwells, and the second hit the two-hit rule wants
        # never arrived. Measured, a vehicle reporting in on an unlocked
        # carrier gave 1 hit in 7 visits and no alert; on a locked carrier,
        # which is already in this rotation, it alerted three cycles in.
        # Priority 1 is a track that is due a look: something is actually
        # there, and how often to go back is its own business -- fast while it
        # still has to prove itself, then at the rate it really transmits, so
        # measuring a channel more often than it ever says anything stops
        # costing power. Priority 2 is the locked site's partners. Priority 3,
        # below, is the rest of the band. A channel with nothing on it is not
        # in any of them, and the sweep queue is its own cooldown: it cannot
        # come back round until the sweep wraps.
        due=[tr.freq_hz for tr in self.alarm.tracks.revisit_due(now)]
        partners=sorted(self.sites.uplink_partners(now))
        fast=sorted(set(partners)|set(due))
        watch=band if band else fast
        if not watch:
            return None
        keys={int(round(p)) for p in watch}
        # While the follow-up window is open the receiver alternates between
        # that window and the ordinary rotation. Parking on it exclusively for
        # long enough to outlast a repeat is long enough to blind everything
        # else -- measured, 0 visits to the other carrier of the site in 10
        # dwells, which is exactly what scenario 18 exists to catch.
        following=(self._follow_left>0 and float(now)<self._follow_until
                   and self._follow_left%2==0)
        follow=[f for f in self._follow if int(round(f)) in keys] if following else []
        if follow:
            rotated=[follow[0]]+[p for p in watch if int(round(p))!=int(round(follow[0]))]
            return {'fast':fast,'partners':partners,'targets':rotated,
                    'follow':follow,'turn':self._watch_turn,'lane':'follow'}
        # Alternate a partner-anchored dwell with the next slice of the band
        # sweep. The partners are the likeliest channels and keep a revisit of
        # a few seconds; the sweep guarantees that every other channel is
        # looked at at all, which is the whole point.
        turn=self._watch_turn+1
        # Three lanes, in order. A track that is due a look is something that
        # is actually there, so it goes first -- merged into the partner list
        # it could be made to wait behind however many partners a locked site
        # happened to name. The run cap is what keeps the other two lanes
        # alive: without it a channel that never stops transmitting is due
        # every round and nothing else is ever measured.
        cap=max(1,int(self.cfg.get('uplink_track_run',2)))
        if due and self._track_run<cap:
            head=[f for f in due if int(round(f)) in keys] or list(due)
            rotated=head+[p for p in watch if int(round(p)) not in
                          {int(round(x)) for x in head}]
            return {'fast':fast,'partners':partners,'targets':rotated,
                    'follow':follow,'turn':turn,'lane':'track'}
        if partners and turn%2==0:
            start=self._partner_idx%len(partners)
            rotated=partners[start:]+partners[:start]
            return {'fast':fast,'partners':partners,'targets':rotated,
                    'follow':follow,'turn':turn,'lane':'partner'}
        if True:
            # A queue, drained and refilled, exactly as the downlink pass
            # works -- not a rotating cursor. A cursor cannot express "this one
            # channel still owes me a look": plan_dwell places the tuner where
            # it covers the most of what it is handed, so handed a rotation it
            # centres behind the cursor and remeasures what was just swept (a
            # 199-channel pass took 59 dwells that way), and handed only what
            # lies ahead it strands the channel the DC guard skipped (195 of
            # 199 after 200 dwells). Draining a queue ends both.
            queue=self._uplink_queue or list(watch)
            rotated=list(queue)
        return {'fast':fast,'partners':partners,'targets':rotated,
                'follow':follow,'turn':turn,'lane':'band'}

    def _watch_work(self,now):
        """Dwell on the uplink partners of the locked base stations.

        A verified hit is followed straight away: the next dwells go back to
        the window that heard it, so the second confirmation arrives while the
        handset is still keyed up. Without that, confirmation waited for the
        watch rotation to come round again -- measured on rfeye at 0.9.25 with
        five locked carriers, every 9 s per channel, and with ten over 20 s --
        and a push-to-talk of a few seconds was over long before the second
        look, so a car could transmit right alongside and never raise an
        alert. The follow-up is bounded and is not re-armed by its own hits, so
        a long transmission cannot keep every other channel unwatched.
        """
        plan=self._uplink_plan(now)
        if plan is None:
            self._follow=[]; self._follow_left=0
            return []
        partners=plan['partners']; rotated=plan['targets']
        follow=plan['follow']; turn=plan['turn']; lane=plan['lane']
        self._track_run=self._track_run+1 if lane=='track' else 0
        window_open=self._follow_left>0 and float(now)<self._follow_until
        if window_open:
            self._follow_left-=1
        else:
            self._follow=[]; self._follow_left=0; self._follow_until=0.0
        if not follow:
            self._watch_turn=turn
        results=self._verify(rotated,'UPLINK')
        if not follow:
            covered=max(1,len(self.dwell_channels))
            if lane=='partner' and partners:
                self._partner_idx=(self._partner_idx+covered)%len(partners)
            elif lane=='band':
                if not self._uplink_queue:
                    self._uplink_queue=self._uplink_band_channels() or list(partners)
                    self._uplink_sweeps+=1
                done={int(round(x)) for x in self.dwell_channels}
                self._uplink_queue=[x for x in self._uplink_queue
                                    if int(round(x)) not in done]
            # Follow a hit only while it still has something to prove. A
            # channel whose alert is already up re-armed the follow-up on
            # every rotation dwell that reached it, so a handset that simply
            # kept talking held the receiver on its own window and the other
            # carriers went unvisited -- measured, 0 visits in 10 dwells.
            done=self.alarm.confirmed_channels()
            hits=[r.freq_hz for r in results
                  if r.ok and int(round(float(r.freq_hz))) not in done]
            if hits:
                # Stay on the window long enough to outlast one repeat of
                # whatever is transmitting there. A terminal that reports in
                # periodically sends the next one seconds later, and a
                # follow-up counted only in dwells ended before it -- three
                # dwells was about 2.4 s. Bounded in both, so a channel cannot
                # hold the receiver either.
                self._follow=[float(h) for h in hits]
                self._follow_left=max(0,int(self.cfg.get('uplink_follow_dwells',8)))
                self._follow_until=float(now)+max(
                    0.,float(self.cfg.get('uplink_follow_s',7.0)))
        return results

    def _uplink_band_channels(self):
        """Every 25 kHz uplink channel in 380-385 MHz, low to high.

        Until 0.9.35 the watch list was exactly the duplex partners of the
        locked downlinks -- on the reference unit two channels of the two
        hundred the band holds, so 99% of it was never looked at. A vehicle
        registered on any other carrier, or on a neighbouring site, transmitted
        into a receiver that was not listening there and never could be. That
        is why an ambulance never raised an alert: not a sensitivity problem,
        a coverage one.

        In the Netherlands 380-385 MHz carries nothing but emergency-services
        terminals, so a channel needs no introduction from a locked downlink to
        be worth testing -- the waveform test is the evidence either way. The
        partners still come first, and a hit on one of them still confirms on a
        single dwell; see UplinkAlarm.update.
        """
        if not bool(self.cfg.get('uplink_sweep_band',True)):
            return []
        lo=float(self.cfg.get('mobile_band_start_hz',380e6))
        hi=float(self.cfg.get('mobile_band_end_hz',385e6))
        key=(lo,hi,float(self.cfg.get('tetra_channel_spacing_hz',25000.)))
        if self._band_cache_key!=key:
            step=max(1.0,key[2])
            f=self._raster(lo+step,lo)
            out=[]
            while f<hi:
                out.append(float(f)); f+=step
            self._band_cache_key=key; self._band_cache=out
        return list(self._band_cache)

    def _scan_cycle(self):
        t0=time.perf_counter(); self.last_scan_windows=0
        try:
            now=time.time()
            site_results=[]; watch_results=[]
            self.dwell_channels=[]
            # The uplink is watched whether or not a downlink is locked. Until
            # 0.9.35 stage 2 ran only behind a lock, so a unit that had not yet
            # proved a base station -- which, driving, is most of the time in
            # every new cell -- was not listening to 380-385 MHz at all. The
            # lock is still what the panel reports and still what decides which
            # channels confirm on one hit, but it is no longer the gate on
            # hearing anything.
            watch_results=self._watch_work(now)
            # A TETRA site runs several carriers and a handset can be on any
            # of them, so an unfinished band pass is finished even after the
            # first lock -- stopping early would leave real uplink channels
            # unwatched. It runs on alternate cycles so the uplink watch keeps
            # priority.
            self._alt_cycle=not self._alt_cycle
            # Alternate cycles carry the band pass; a due re-proof gets a turn
            # whenever it comes round. _site_work owns the timer, so a pass
            # dwell can no longer postpone the next re-proof.
            due=(now-self._site_verify_at
                 >= self._reverify_interval(self.sites.locked(now)))
            # How the two stages share the cycles. The uplink sweep is the
            # detector now, so it runs every cycle; the downlink pass rides
            # along on alternate ones. With nothing locked it gets all of
            # those, because a lock is what lets a partner channel confirm on a
            # single hit -- worth having, just no longer worth waiting for.
            # While a hit is being followed up the uplink gets the whole cycle:
            # the handset may unkey at any moment, and nothing a downlink dwell
            # could learn is urgent by comparison.
            if not self._follow_left:
                if self.sites.locked(now):
                    # One cycle in site_pass_share, not one in two. Measured on
                    # the field unit, the band pass was taking 9 of 22 cycles
                    # while the site was already locked with six carriers --
                    # half the receiver's time spent re-proving 390-395 MHz,
                    # which no longer decides whether anything alerts.
                    share=max(2,int(self.cfg.get('site_pass_share',5)))
                    self._site_share+=1
                    run_site=(self._site_queue and self._site_share%share==0) or due
                else:
                    run_site=self._alt_cycle or due
                if run_site:
                    site_results=self._site_work(now)

            now=time.time()
            verified=[r for r in watch_results if r.ok]
            watched=[r.freq_hz for r in watch_results]
            confirmed,level,peaks=self.alarm.update(
                verified,watched,now,trusted=self.sites.uplink_partners(now))
            self._log_hits(now,verified,confirmed)
            locked=self.sites.locked(now)

            # The 380-385 MHz sweep that used to run here fed the spectrum
            # page and nothing else. It cost a full wide capture every fourth
            # cycle -- measured, the difference between a 1.1 s and a 1.7 s
            # round -- to draw a picture the detector never read. The uplink
            # channels that matter are dwelt on individually by _watch_work.

            # With no lock and an exhausted shortlist there is nothing to
            # verify until the next survey is due. Without this the scan
            # thread spins at full speed doing no work, which is what the
            # first live run on real hardware showed it doing.
            if not site_results and not watch_results and not self._site_queue:
                wait=max(0.25,min(2.0,float(self.cfg.get(
                    'survey_idle_interval_s',15.0))-(now-self._survey_at)))
                time.sleep(wait)

            # The radio can be filling the next buffer while the rest of
            # this cycle runs.
            self._prefetch_uplink(now)

            state='ALERT' if confirmed else ('LOCKED' if locked else 'SEARCHING')
            # The bars come from the tracks, not from whatever this one scan
            # round returned, so they mean "these are the signals near me"
            # and stop jumping channel every dwell. Their height is the RF
            # level: how TETRA-like the waveform looked barely moves once a
            # signal is decodable at all, and is not what someone glancing at
            # the screen is asking.
            weak=float(self.cfg.get('ui_level_weak_db',8.0))
            strong=float(self.cfg.get('ui_level_strong_db',26.0))
            nshow=int(self.cfg.get('max_signals',3))
            shown=[tr.as_dict(now,weak,strong) for tr in
                   self.alarm.tracks.top(now,nshow)]
            for row in shown:
                row['channel']=carrier_number(row['freq_hz'],self.cfg)
            if confirmed and not shown:
                # The alert is being held through a gap between transmissions,
                # and the track that raised it has gone quiet -- which is what
                # a gap is. Falling to an empty list here stopped the buzzer
                # the moment the vehicle drew breath, instead of letting the
                # alert age out over uplink_alert_hold_s.
                shown=[self._peak_row(r) for r in peaks[:nshow]]
            # Every channel the dwell measured, not the first twelve. A
            # dwell covers up to 48, so a recording of a drive past a
            # vehicle kept a quarter of the evidence -- and the quarter
            # it kept was the head of the queue, not the interesting
            # part. The recordings are the only real evidence there is.
            keep=max(12,int(self.cfg.get('snapshot_phy_rows',64)))
            phy_rows=[r.as_dict() for r in (watch_results+site_results)[:keep]]

            with self.lock:
                self.detector_state=state
                self.peaks=shown if confirmed else []
                self.mobile_peaks=[self._peak_row(r) for r in verified]
                self.site_peaks=[dict(s) for s in locked]
                self.mobile_level=float(level) if confirmed else 0.
                self.site_level=float(max([s['quality'] for s in locked],default=0.))
                self.activity_confidence=float(level)
                self.mobile_confirmed=bool(confirmed)
                self.alert_provisional=bool(confirmed and self.alarm.provisional)
                self.provisional_hit_at=float(self.alarm.provisional_hit_at)
                self.last_phy=phy_rows
                self.last_update=now; self.status='LIVE'; self.error=''
                self.demo_active=False; self.last_good_scan=now; self.scan_failures=0
                self._usb_resets=0; self._usb_backoff=0.
                self.last_cycle_ms=(time.perf_counter()-t0)*1000.
            if self._sdr_lost_at:
                self._power_log(now,'SDR back after %.0f s'%(time.time()-self._sdr_lost_at))
                self._sdr_lost_at=0.
            return True
        except Exception as e:
            err=str(e)
            low=err.lower()
            # Only a device that is present but has stopped answering is worth
            # resetting. 'open failed' means it is not on the bus at all, and
            # every _samples() failure is wrapped as 'read failed', so matching
            # that text resets on absence too -- which is precisely what kept
            # the dongle from coming back.
            job,self._prefetch=self._prefetch,None
            if job is not None:
                try: self._pump.wait(job,4.0)
                except Exception: pass
            # A dongle that was working and has just stopped is the strongest
            # sign there is that the radio asked for more than the supply --
            # or the dongle -- could give, so the ladder steps down. Only the
            # moment it is lost counts: every failed open while it is gone is
            # the same incident, not a reason to keep stepping.
            # ...and a capture that was cut short because the app is being
            # stopped is not a failure of anything. Up to 0.10.4 every clean
            # stop -- an update installing, the service restarting -- was
            # written down as "SDR lost: capture aborted" and cost the ladder a
            # step and a strike, so a unit that was only ever restarted worked
            # its way down to the floor and stayed there for hours.
            stopping=(not self.running) or ('capture aborted' in low)
            if (self.last_good_scan and self.scan_failures==0
                    and not self._sdr_lost_at and not stopping):
                t=time.time()
                gone=not self._sdr_present()
                why='SDR lost: '+('off the USB bus' if gone else err[:60])
                in_use=self._duty_limit(t)
                self._sdr_lost_at=t
                if self.ladder.event(t,why,in_use=in_use):
                    self._power_log(t,'DROP %s at %d%% -> cap %d%%'%(
                        why,round(in_use*100),round(self.ladder.cap*100)))
                else:
                    self._power_log(t,'%s (same incident)'%why)
            if ('timeout' in low or 'short read' in low or 'stuck' in low) and 'open failed' not in low:
                self._recover_sdr_usb()
            power=self._power_warning() or self._power_history
            if power:
                err=power+': '+err
            with self.lock:
                self.scan_failures+=1
                recent=bool(self.last_good_scan and time.time()-self.last_good_scan<8)
                if not recent and self.scan_failures>=3:
                    self.status='NO SDR'; self.detector_state='NO SDR'
                    self.peaks=[]; self.mobile_peaks=[]; self.site_peaks=[]
                    self.mobile_level=0.; self.site_level=0.
                    self.activity_confidence=0.; self.mobile_confirmed=False
                    self.alert_provisional=False
                    self.alarm.reset()
                    self.spectrum_freqs=np.array([],dtype=np.float64)
                    self.spectrum_db=np.array([],dtype=np.float32)
                self.error=err; self.demo_active=False
            return False

    @staticmethod
    def _peak_row(r):
        """PhyResult -> the peak dict the UI and recordings consume."""
        return {'freq_hz':float(r.freq_hz),'channel':carrier_number(r.freq_hz),
                'level':float(r.quality),
                'signal_strength':float(r.quality),'confidence':float(r.quality),
                'quality':float(r.quality),'snr_db':float(r.snr_db),
                'rf_snr_db':float(r.snr_db),'duty':float(r.duty),
                'band':'MOBILE' if r.role=='UPLINK' else 'SITE',
                'role':str(r.role),'reason':str(r.reason),
                'dqpsk_m':float(r.dqpsk_m),
                'dqpsk_phase_spread':float(r.dqpsk_phase_spread),
                'dqpsk_selectivity':float(r.dqpsk_selectivity),
                'frame_line_ratio':float(r.frame_line_ratio),
                'slot_quantisation':float(r.slot_quantisation),
                'burst_ms_median':float(r.burst_ms_median),
                'occupied_bw_hz':float(r.occupied_bw_hz),
                'boundary_reject_db':float(r.boundary_reject_db),
                'last_seen':time.time()}

    def _demo_once(self):
        t=time.time()
        vals=[.1+.75*max(0,math.sin(t*.7))**8,.06+.5*max(0,math.sin(t*.44+1.7))**10,
              .04+.85*max(0,math.sin(t*.28+3.1))**12]
        base=float(self.cfg.get('mobile_band_start_hz',380e6))
        span=float(self.cfg.get('mobile_band_end_hz',385e6))-base
        peaks=[{'freq_hz':base+span*(.2+i*.3),'channel':carrier_number(base+span*(.2+i*.3)),
                'snr_db':8+v*30,'rf_snr_db':8+v*24,
                'signal_strength':v,'level':v,'quality':v,'confidence':min(1,.2+v*.8),
                'band':'MOBILE','role':'UPLINK','reason':'DEMO','last_seen':t}
               for i,v in enumerate(vals) if v>.12]
        x=np.linspace(0,1,220); spec=-105+4*np.sin(x*15+t)
        with self.lock:
            self.peaks=peaks[:3]; self.mobile_peaks=peaks[:3]
            self.site_peaks=[{'freq_hz':base+10e6+span*.5,'quality':.45,'hits':3}]
            self.mobile_level=max(vals); self.site_level=.45
            self.activity_confidence=max([p['confidence'] for p in peaks],default=0)
            self.mobile_confirmed=bool(peaks)
            self.detector_state='DEMO'
            self.spectrum_freqs=np.linspace(base,base+span,len(x))
            self.spectrum_db=spec.astype(np.float32)
            self.noise_floor_db=-103.; self.last_update=time.time()
            self.status='DEMO'; self.error=''; self.demo_active=True
        time.sleep(.08)
