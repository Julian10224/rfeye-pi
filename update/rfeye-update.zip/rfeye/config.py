from pathlib import Path
import json
import os
import subprocess
import threading
import time


def _kiosk_guard_worker():
    """Keep Raspberry Pi desktop chrome out of the RF Eye appliance session."""
    uid = str(os.getuid())
    while True:
        try:
            own_uid = os.getuid()
            for proc_dir in Path("/proc").glob("[0-9]*"):
                try:
                    if proc_dir.stat().st_uid != own_uid:
                        continue
                    argv = [x for x in (proc_dir / "cmdline").read_bytes().split(b"\0") if x]
                    if argv[-2:] in ([b"/usr/bin/lwrespawn", b"/usr/bin/wf-panel-pi"], [b"/usr/bin/lwrespawn", b"/usr/bin/pcmanfm-pi"]):
                        os.kill(int(proc_dir.name), 15)
                except (FileNotFoundError, ProcessLookupError, PermissionError, ValueError):
                    pass
        except Exception:
            pass
        for process_name in ("wf-panel-pi", "pcmanfm-pi", "lxpanel", "squeekboard"):
            try:
                subprocess.run(
                    ["pkill", "-u", uid, "-x", process_name],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    check=False,
                    timeout=2,
                )
            except Exception:
                pass
        time.sleep(3.0)


def _start_kiosk_guard():
    if not os.environ.get("WAYLAND_DISPLAY"):
        return
    threading.Thread(target=_kiosk_guard_worker,name="rfeye-kiosk-guard",daemon=True).start()


_start_kiosk_guard()

try:
    from wifi_patch import install_app_patch
    install_app_patch()
except Exception:
    pass

try:
    from compact_display_patch import install_app_patch as install_compact_display_patch
    install_compact_display_patch()
except Exception:
    pass

# The detector profile load_config() migrates every unit to. DEFAULTS carries
# the same number, so code and tests that read DEFAULTS directly see what a
# running unit sees; they said 11 while every unit ran 13.
DETECTOR_PROFILE_VERSION = 13

# The radio profile, migrated separately from the detector's because it is a
# user setting rather than a calibration. 1 (0.11.0) is drive mode by
# default: see low_power_mode.
POWER_PROFILE_VERSION = 1

DEFAULTS = {
    "detector_profile_version": DETECTOR_PROFILE_VERSION,
    "power_profile_version": POWER_PROFILE_VERSION,
    "ui_width": 480,
    "ui_height": 800,
    "physical_width": 800,
    "physical_height": 480,
    "rotation": "cw",
    "fullscreen": True,
    "scan_start_hz": 380_000_000,
    "scan_end_hz": 395_000_000,
    "sdr_device_index": 0,

    # Wideband survey. Only ever used to shortlist downlink carriers worth
    # verifying, and to draw the spectrum page. It decides nothing.
    "sample_rate": 2_048_000,
    "fft_size": 1024,
    "survey_capture_ms": 48.0,
    "survey_interval_s": 60.0,
    "survey_idle_interval_s": 15.0,
    "survey_min_snr_db": 6.0,
    "survey_flatness_weight": 0.5,
    "survey_flatness_tolerance_db": 6.0,
    "survey_max_candidates": 12,
    "mobile_percentile": 95.0,

    # Verification dwell. 2.016 MS/s is exactly 112x the 18000 baud TETRA
    # symbol rate, so decimating by 56 gives the same 36 kS/s channel baseband
    # the tests were calibrated on. 2^20 samples is 0.520 s, about 9 TDMA
    # frames.
    #
    # Until profile 10 this was 288 kS/s, and at that rate the RTL2832U hands
    # back real carriers from 1.15 MHz away as if they were on the channel
    # being measured. Measured on rfeye, 14 September 2026: 390.0375 and
    # 390.6125 passed the full TETRA test at 16-18 dB at 288 kS/s, and were
    # plain noise at 250 kS/s, 1.008 MS/s, 2.016 MS/s and in rtl_power -- they
    # are 391.1875 and 391.7625, 1150 kHz higher. So units locked phantom
    # carriers and watched their non-existent uplinks. At 2.016 MS/s the
    # dongle's own filter is in use, and one dwell spans most of a megahertz: a whole
    # site's uplinks in one or two dwells instead of one channel per dwell.
    "phy_sample_rate": 2_016_000,
    "phy_dwell_log2": 20,
    "phy_decimation": 56,
    # How far from the tuner centre a channel is still measured. It was
    # +-600 kHz, which takes five dwells to cross 380-385 MHz; the capture
    # itself is 2.016 MHz wide, so two fifths of every one was thrown away.
    # Measured on a reference unit's own recording (noise, 382.46 MHz, gain
    # 37.2): flat within 0.8 dB out to +-775 kHz, -1.6 dB at -825, -0.2 at
    # +825, -2.6 at -875, -0.8 at +875 -- the tuner's IF filter, which takes
    # signal and noise down together. At +-850 kHz the band is three dwells.
    "phy_max_offset_hz": 850_000.0,
    "phy_timing_phases": 8,
    # Cheap level check before the waveform test. A swept band is nearly
    # all empty -- 205 of 208 channels on the field unit were flat noise --
    # and each was paid for at full price. One prefix sum over the capture
    # levels every channel at once. The screen reads high by construction
    # (a mean in linear power against a whole-capture noise floor), so it
    # can only drop what the real test would drop; measured against it,
    # -0.6 to +0.5 dB, and the margin below covers that several times over.
    "phy_screen": True,
    "phy_screen_margin_db": 2.0,

    # TETRA acceptance limits. These mirror tetra_phy.LIMITS and are the
    # values calibrated by scripts/tetra-phy-selftest.py. Loosening any of
    # them trades false alarms back in; they are exposed so a unit can be
    # tuned in the field without editing code, not because they are guesses.
    "phy_min_snr_db": 8.0,
    "phy_min_occupied_bw_hz": 14000.0,
    "phy_max_occupied_bw_hz": 30000.0,
    "phy_min_boundary_reject_db": 6.0,
    "phy_max_flatness_db": 14.0,
    "phy_max_centre_error_hz": 8000.0,
    "phy_min_dqpsk_m": 0.20,
    "phy_min_dqpsk_phase_spread": 0.50,
    "phy_min_dqpsk_selectivity": 1.35,
    "phy_downlink_min_duty": 0.15,
    "phy_uplink_min_duty": 0.04,
    "phy_uplink_max_duty": 0.85,
    "phy_uplink_min_frame_ratio": 3.0,
    "phy_uplink_min_slot_quantisation": 0.45,
    "phy_uplink_min_bursts": 3,
    # A sensitive uplink below phy_shape_min_snr_db is judged on its
    # waveform alone, down to phy_uplink_min_snr_db. The -10 dB bandwidth
    # cannot be measured on a burst only 10 dB up, and asking for it cost
    # about 6 dB: a single slot needed 14 dB, now 8. See tetra_phy.analyse.
    "phy_uplink_min_snr_db": 5.0,
    "phy_shape_min_snr_db": 12.0,

    # Sensitive detection. The alarm fires on a short uplink
    # control/registration burst -- what a moving mobile keys up crossing
    # cells even when nobody is talking -- and not only on a held voice call.
    # It confirms on a single verified hit. This is what a car driving past
    # emits most of the time; the trade is more false alarms, since a lone
    # freak pass now alerts. Every hit still had to pass the full 25 kHz shape
    # and pi/4-DQPSK / 18 kbaud / selectivity tests, so noise, the base
    # station bleeding in under overload, and other digital systems are still
    # rejected.
    #
    # Since 0.9.33 this is not a setting. It shipped as a toggle in 0.9.29 and
    # there was never a reason to reach for the other position: strict mode
    # only answers "is someone holding a call", which is not the question the
    # device is for, and a unit left on strict is a unit that cannot see the
    # thing it was built to see. load_config() forces it on, so a unit that
    # saved OFF gets it back on the update rather than staying quietly deaf.
    # The strict path stays in tetra_phy for the regression tests, which
    # measure both.
    "uplink_sensitive": True,
    # Sweep the whole 380-385 MHz uplink band, not only the duplex partners of
    # the locked downlinks. Until 0.9.35 the watch list was exactly those
    # partners -- on the reference unit two channels of the two hundred the
    # band holds, so 99% of it was never examined and a vehicle registered on
    # any other carrier, or on a neighbouring site, was invisible however close
    # it drove past. In the Netherlands this band carries nothing but
    # emergency-services terminals, so a channel needs no introduction from a
    # locked downlink to be worth testing.
    "uplink_sweep_band": True,
    # Capture on its own thread so the radio fills the next buffer while
    # the last one is being measured. Strictly alternating, the field
    # unit spent 0.70 s capturing and 0.93 s analysing per cycle, so it
    # listened to 380-385 MHz 11% of the time. Set false to go back to
    # one thread if a unit ever misbehaves; nothing else changes.
    "scan_pipeline": True,
    # The share of the time the dongle may stream. This is the knob that
    # decides current draw: an RTL-SDR pulls its several hundred mA while
    # it is streaming, so spending less means streaming less of the time.
    # 0.9.37 moved it without naming it -- capture on its own thread with
    # a 0.10 s pause read about 88% of the time against 37% before, and a
    # field unit threw the dongle off the bus 169 s after boot with the
    # under-voltage flag set. ECO is the shipped default; Max power lifts
    # the limit; the power ladder below caps either.
    "sdr_duty_eco": 0.55,
    # With nothing heard recently the band is swept cooler: there is no
    # track to follow, so the extra current buys nothing.
    "sdr_duty_idle": 0.45,
    "sdr_duty_max_power": 1.0,
    "sdr_duty_window_s": 20.0,
    # The power ladder (0.10.2): the most the radio may stream, learned from
    # the supply. A fresh under-voltage or a dongle that drops off the bus
    # takes it straight to power_ladder_drop_to; every power_ladder_step_s of
    # trouble-free listening climbs one step. 1.0 means "whatever the mode
    # allows".
    #
    # Since 0.10.8 only a lost dongle is held against the step it happened
    # on: that step stays off limits for power_ladder_retry_s, doubling once,
    # and that is what power-state.json carries across a reboot. An
    # under-voltage never takes the radio below the safe step, and
    # power_ladder_floor_dips of them at that step inside
    # power_ladder_floor_window_s mean the rail sags whatever the radio does
    # -- so the radio is no longer limited for it. See power.py for the unit
    # that spent a drive at 22% because of the old rules.
    "power_ladder": [0.22, 0.30, 0.35, 0.40, 0.45, 0.55, 0.70, 0.85, 1.0],
    "power_ladder_drop_to": 0.30,
    "power_ladder_step_s": 300.0,
    "power_ladder_retry_s": 1800.0,
    "power_ladder_debounce_s": 30.0,
    "power_ladder_floor_dips": 3,
    # After a dip (not a lost dongle) the radio goes straight back to where
    # it was once the rail has held this long (0.11.2), instead of climbing a
    # step every power_ladder_step_s: the stream only runs above 85%.
    "power_ladder_dip_return_s": 120.0,
    "power_ladder_floor_window_s": 1800.0,
    "power_ladder_persist": True,
    # The kernel's under-voltage alarm is a file read, so it is watched every
    # couple of seconds; power.log gets a line per event and per minute.
    "power_poll_s": 2.0,
    "power_log_heartbeat_s": 60.0,
    # Capture and analysis only overlap above this radio share. Below it one
    # thread already reaches the limit, and the overlap is only a higher peak
    # current -- exactly what a rail that has just sagged cannot use.
    "scan_pipeline_min_duty": 0.40,
    "low_power_min_pause_s": 0.0,
    # Continuous capture (0.11.0). Separate dwells listened to each uplink
    # channel about 9% of the time (power.log, hear=9.4%), so a vehicle that
    # sent a handful of short bursts while passing was mostly missed: one
    # burst in range was a 9% chance, five 39%. Streaming keeps the dongle
    # reading into a ring buffer, a cheap per-channel energy trigger runs on
    # every block, and only the ~65 ms around a burst of stream_trigger_min_s
    # or longer goes to the full waveform test. The window covers the locked
    # site's partners (stream_partner_weight turns in the rotation) and the
    # rest of the band in turn; the downlink gets one dwell between holds,
    # and only when it is due.
    #
    # It runs only when the radio may stream at least stream_min_duty of the
    # time -- drive mode, with the power ladder at the top -- and falls back
    # to dwells on its own, for stream_retry_s, if the stream fails while the
    # dongle is still on the bus.
    "stream_mode": True,
    "stream_min_duty": 0.85,
    "stream_hold_s": 8.0,
    "stream_hold_max_s": 30.0,
    "stream_partner_weight": 2,
    # With a main carrier locked (0.11.1): stream_hold_s on its control
    # channel, then one visit of this long to one other window, in turn.
    "stream_hold_other_s": 2.0,
    "stream_fft_size": 1024,
    "stream_trigger_db": 3.5,
    "stream_trigger_min_s": 0.005,
    "stream_trigger_max_s": 0.060,
    "stream_smooth_rows": 4,
    "stream_gap_rows": 3,
    "stream_holdoff_s": 0.30,
    # Measured in an emulation of a Pi 3 B+ at its 900 MHz ceiling: the FFT
    # on every row and an analysis every 0.3 s per active channel came to
    # more than one core. Every other row, and a channel left alone for 2 s
    # after it verified (1 s after it failed), is what keeps up.
    "stream_row_stride": 2,
    "stream_holdoff_hit_s": 2.0,
    "stream_holdoff_fail_s": 1.0,
    # 2^17 samples, 65 ms around the burst. 130 ms cost half a second of a
    # Pi 3 B+ per analysis; 65 ms recognises the same bursts (a subslot
    # slightly better: it is a larger share of the window) at 57% of the cost.
    "stream_snippet_log2": 17,
    "stream_max_channels": 8,
    "stream_publish_s": 1.0,
    "stream_ring_s": 2.0,
    "stream_buf_len": 131072,
    "stream_buf_num": 12,
    "stream_stall_s": 2.5,
    "stream_retry_s": 600.0,
    # How many per-channel results a snapshot carries. One dwell measures
    # up to 48 channels; at 12 a recording kept a quarter of what the
    # receiver saw, which is how a drive past a vehicle could be analysed
    # afterwards and answer nothing.
    "snapshot_phy_rows": 96,
    # One cycle in this many goes to the 390-395 MHz band pass once a
    # site is locked. It was one in two, measured at 9 of 22 cycles on a
    # unit that already held six carriers -- half the receiver's time
    # re-proving a lock that no longer gates the alarm.
    "site_pass_share": 5,
    # The same, with nothing locked. It was one cycle in two: a unit
    # entering a new cell was half deaf on the uplink while it looked for a
    # base station, although a lock stopped being a condition for an alert
    # in 0.9.35.
    "site_search_share": 5,
    # ...except while a carrier that verified this recently is still short of
    # a lock: one cycle in two, the cheapest route to a lock.
    "site_candidate_fresh_s": 120.0,
    # How many verified hits a channel *outside* the locked partners needs
    # before it shows. One, since 0.10.3, as a Blu Eye does: it warns on the
    # pulse. Two had it hearing a vehicle on any other carrier in 4% of
    # simulated 45 s drive-bys, because at ~4% listening time the second
    # burst almost never landed in a capture. What the second hit still
    # decides is how loud: see uplink_single_hit_full_db.
    "uplink_unknown_confirm_dwells": 1,
    # A single hit on a channel no locked site vouches for is provisional --
    # a bar and one short beep -- unless it is at least this strong (the
    # yellow part of the bar), or until a second hit or a site lock backs it
    # up. Only then does the running alarm sound.
    "uplink_single_hit_full_db": 14.0,
    # Which verified signals make a sound (0.11.2), as a Blu Eye's City mode:
    # "city" only those at least uplink_near_city_db at the antenna, "close"
    # uplink_near_close_db, "all" every one. Below the threshold a signal is
    # shown and silent. On the reference unit the network's own masts,
    # kilometres away, measure 15-33 dB; a vehicle beside it puts the ADC
    # near its rails, 35 dB and up. A setting on the panel.
    "alert_range": "city",
    "uplink_near_city_db": 28.0,
    "uplink_near_close_db": 38.0,
    # 100 is a peak hold over the dwell's ~146 spectrum rows. 98 kept the top
    # three of them, and a single 14 ms TETRA slot is four -- so the level of
    # the shortest real transmission was averaged away before any test saw it.
    # The bias of a peak hold lands on the noise reference too, so an empty
    # channel still measures 0.6 dB. See Channelizer.psd.
    "phy_uplink_sensitive_percentile": 100.0,

    # C2000 network lock. Slow to acquire, slower to lose.
    "duplex_split_hz": 10_000_000.0,
    "site_lock_hits": 3,
    "site_unlock_misses": 4,
    "site_lock_stale_s": 600.0,
    "site_lock_max_age_days": 21.0,
    "site_forget_s": 1800.0,
    "site_reverify_s": 60.0,
    # How often the whole band is swept again once a network is locked. A site
    # runs several carriers and each one carries its own uplink partner, so a
    # single locked carrier watches a single uplink channel.
    #
    # 300 s dated from the 288 kS/s dwell, when a pass itself took 300 s. At
    # 2.016 MS/s a pass is about nine dwells, 30 s, so waiting five minutes
    # after the first lock before looking for the site's other carriers was
    # pure delay -- measured on rfeye, a second carrier locked only on the
    # pass after next. Driving, that is kilometres of unwatched uplinks. At
    # 120 s a pass takes about a quarter of the cycles, and each uplink
    # channel is still examined every ~3 s while one runs.
    "site_rescan_s": 120.0,
    # How long silence everywhere at once stops being an idle carrier and
    # starts being a deaf receiver. Collective on purpose: see
    # SiteRegistry.heard_recently.
    "site_silence_window_s": 180.0,
    "site_state_persist": True,

    # Uplink alarm smoothing. Everything reaching this has already passed the
    # full waveform test, so these only stop the display flickering between
    # transmissions.
    "uplink_confirm_dwells": 2,
    "uplink_confirm_visits": 4,
    # The same window for a channel with no locked partner. Wider,
    # because something that reports in every few seconds is silent on
    # most looks and its two hits land several visits apart.
    #
    # Thirty since 0.10.8, for the same length of time. A visit used to be
    # one sweep dwell in ten; with every dwell measuring its whole window a
    # channel is visited about one dwell in three, so ten visits had shrunk
    # from a minute and a half to half a minute. uplink_state_max_age_s is
    # still what bounds it in seconds.
    "uplink_confirm_visits_unknown": 30,
    "uplink_state_max_age_s": 90.0,
    "uplink_alert_hold_s": 12.0,
    # After a verified uplink hit, how many dwells go straight back to that
    # window so the second confirmation comes while the handset is still
    # keyed up, instead of whenever the watch rotation next comes round.
    # How long a verified hit keeps the next dwells on its own window, in
    # dwells and in seconds, whichever ends first. Three dwells was about
    # 2.4 s, which is shorter than the gap between two transmissions from
    # a terminal that reports in periodically -- so the second hit an
    # unknown channel needs could fall just outside the window that
    # exists to catch it.
    "uplink_follow_dwells": 8,
    "uplink_follow_s": 7.0,
    # How long a channel that produced verified TETRA stays in the fast
    # rotation. A hit on a channel with no locked partner used to be the
    # only one it ever got -- the sweep came back about once every fifteen
    # dwells, so the second hit the two-hit rule wants never arrived.
    # How a track is followed once it exists: fast while it still has to
    # prove itself, then at the rate it actually transmits. A confirmed
    # track with a rhythm is revisited at about half its own period --
    # measuring a channel more often than it ever says anything is pure
    # current.
    "track_revisit_fast_s": 0.8,
    "track_revisit_s": 2.5,
    "track_revisit_cool_s": 3.0,
    # How long after its last transmission a channel keeps its place in
    # the fast rotation. A vehicle reporting in every few seconds is
    # between transmissions most of the time; dropping it back to the
    # band sweep the moment it goes quiet is how one hit used to be the
    # only one a channel ever got.
    "track_hot_s": 60.0,
    # When a signal counts as here, fading, or gone.
    "track_active_s": 2.0,
    "track_fading_s": 5.0,
    "track_forget_s": 90.0,
    "track_forget_quiet_s": 20.0,
    # The bar is the RF level between these two, not the waveform score.
    # How many dwells in a row a track may take before the partner and
    # band lanes get one. Without it a channel that never stops
    # transmitting is due every round and nothing else is measured.
    "uplink_track_run": 2,
    # The bottom of the bar follows the weakest burst that can now be
    # recognised (phy_uplink_min_snr_db). At 8 dB a detection between 5 and
    # 8 dB would have shown no bar and made no sound.
    "ui_level_weak_db": 5.0,
    "ui_level_strong_db": 26.0,

    "tetra_channel_spacing_hz": 25_000.0,
    "tetra_raster_offset_hz": 12_500.0,
    # ETSI EN 300 392-2 numbers a carrier from the band's base frequency:
    # downlink = 300 MHz + carrier * 25 kHz + 12.5 kHz in the 380-400 MHz
    # band, and an uplink shares its downlink's number. 381.1875 MHz is
    # carrier 3647, the number a C2000 terminal itself reports; the uplink
    # band runs 3600-3799. Shown under each bar.
    "tetra_carrier_base_hz": 300_000_000.0,
    "tetra_channel_half_width_hz": 9000.0,

    "sdr_stop_join_s": 8.0,
    "usb_reset_max_attempts": 3,
    "allow_cli_sdr_fallback": False,
    "keep_last_iq": True,
    "rf_record_iq": True,
    # Captures kept as raw IQ next to hits.log without anyone asking: an
    # uplink capture that hits the rails, and one holding something at least
    # evidence_strong_db strong that the waveform test turned down. 2 MB each.
    "evidence_keep": 12,
    # The samples behind what was heard are kept too (0.11.2), one capture a
    # minute at most, eight in all: what sounded can be checked afterwards.
    "evidence_hit_every_s": 60.0,
    "evidence_strong_db": 15.0,
    "mobile_band_start_hz": 380_000_000,
    "mobile_band_end_hz": 385_000_000,
    "site_band_start_hz": 390_000_000,
    "site_band_end_hz": 395_000_000,
    "max_signals": 3,
    # A recording logs what the detector sees for this long. An uplink control
    # burst is a fraction of a second and each uplink channel comes round only
    # every few seconds, so a short window rarely catches one -- 15 s never did
    # across fifteen field recordings. A minute gives a burst about four times
    # the chance of falling inside a visited dwell. The worker clamps to 120 s.
    "rf_record_duration_s": 60.0,
    "ui_fps": 20,
    # Low power mode. The detector keeps a Pi 3 B+ at its full 1.4 GHz around
    # the clock, which on a marginal supply is the difference between the
    # RTL-SDR enumerating and not. This trades time-to-lock for headroom, and
    # it is the user's call, so it lives in the settings menu ("Max power").
    #
    # Off since 0.11.0: drive mode. ECO held the radio to 45-55% of the time
    # and the duty pause on top of that could sleep up to 3 s, so with the
    # rest of a cycle's overheads each uplink channel was heard 9% of the
    # time. On a proper 5 V / 3 A car supply that is pure loss. What protects
    # a weak supply now is the power ladder, which drops on the first dip,
    # and the app, which switches ECO back on while the rail is low.
    "low_power_mode": False,
    "low_power_ui_fps": 8,
    "low_power_idle_ui_fps": 3,
    # The panel's SPI bus is wideband noise in the band while a frame goes
    # down it (measured: +4.7 dB, and a quarter of the captures saturated).
    # A frame is sent only when it differs from the one on the panel, and
    # then between two captures, waiting at most this long for the radio.
    # ui_refresh_s repaints regardless, so a lost frame cannot stay lost.
    "ui_quiet_capture": True,
    "ui_quiet_capture_wait_s": 1.5,
    # Since 0.10.9 the radio waits for the frame as well. A frame is on the
    # wire for about 147 ms after the app hands it over, and its SPI clock
    # (16.667 MHz, measured) has its 23rd harmonic at 383.333 MHz, in the
    # uplink band: the air is held for ui_quiet_panel_hold_s
    # per frame that changed, a touch waits at most ui_quiet_touch_wait_s (one
    # capture) for it, and the radio never waits longer than
    # ui_quiet_radio_wait_s on the panel.
    "ui_quiet_panel_hold_s": 0.35,
    "ui_quiet_touch_wait_s": 0.7,
    "ui_quiet_radio_wait_s": 1.0,
    # While the radio streams (0.11.0) there is no gap between captures. A
    # changed frame goes out at once and the trigger ignores the
    # ui_quiet_stream_blank_s it is on the wire for; and at most one changed
    # frame per ui_quiet_stream_frame_s is sent unless the panel is touched.
    "ui_quiet_stream_blank_s": 0.20,
    "ui_quiet_stream_frame_s": 1.0,
    "ui_refresh_s": 30.0,
    "power_notice_timeout_s": 30.0,
    "low_power_scan_pause_s": 1.5,
    # Once a network is locked the uplink watch is the job, and a TETRA slot
    # is 14.2 ms. Idling for a second and a half between cycles then costs
    # detections rather than saving anything worth having.
    "low_power_locked_pause_s": 0.15,
    # Tuner gain in dB. "auto" was the setting until 0.10.4 and hands the
    # gain to the tuner's AGC, which on both reference dongles filled the
    # 8-bit ADC with noise alone -- 17% of samples clipped in the empty
    # uplink band, 12-27% on the downlink. Swept on a unit with 20 dB
    # carriers: 16.6 dB reads them 2.6 dB low, 33.8-44.5 dB within 0.7 dB of
    # the best, "auto" 1.5 dB low. 37.2 is the middle of the flat part with
    # nothing clipped. Overload steps it down per band and back; see
    # SDRBackend._watch_overload.
    "gain": 37.2,
    "gain_clip_limit": 0.05,
    "gain_backoff_step_db": 4.0,
    "gain_backoff_max_db": 24.0,
    "gain_recover_s": 20.0,
    "ppm": 0,
    "muted": False,
    "startup_chime": True,
    "demo_mode": False,
    "auto_demo_if_no_sdr": False,
    "audio_mode": "adaptive",
    "touch_calibration_affine": [0.0, -0.08831672203765227, 342.6688815060908, -0.12914532218926936, 0.0, 508.31598813696417],
    "buzzer_gpio": 26,
    "buzzer_model": "TMB12A03",
    "buzzer_passive": False,
    "buzzer_active_high": True,
    "buzzer_green_ms": 95,
    "buzzer_yellow_ms": 85,
    "buzzer_red_ms": 75,
    "buzzer_green_gap_ms": 0,
    "buzzer_yellow_gap_ms": 70,
    "buzzer_red_gap_ms": 55,
    "brightness": 1.0,
    "show_frequency": True,
    # The C2000 carrier number under each bar (0.10.3), as a Blu Eye shows
    # its channel number.
    "show_channel": True,
    "show_brand_text": True,
    "touch_invert_x": False,
    "touch_invert_y": False,
    "app_version": "0.11.2",
    "update_manifest_url": "https://raw.githubusercontent.com/Julian10224/rfeye-pi/main/update/manifest.json",
    "title": "RF EYE",
}


# Keys that are calibrated physics, not user preferences. The acceptance
# limits come from ETSI constants and from measurements against real C2000
# carriers; a saved copy of them is not a setting the user chose, it is a
# snapshot of whatever release happened to write the file first.
#
# Persisting them by default froze them: a unit installed on 0.9.0 kept
# phy_downlink_min_duty = 0.80 and phy_min_dqpsk_selectivity = 1.6 through
# 0.9.1 and 0.9.2, so both of those releases' corrections were inert on it
# while the source code said otherwise. They are therefore only written when
# they actually differ from the shipped default -- a deliberate field
# override survives, an accidental fossil does not.
_DETECTOR_PREFIXES = ("phy_", "site_", "survey_", "uplink_", "ui_level_", "gain_",
                      "ui_quiet_", "stream_")
_DETECTOR_KEYS = (
    "sample_rate", "fft_size", "duplex_split_hz", "gain",
    "mobile_band_start_hz", "mobile_band_end_hz",
    "mobile_percentile",
    "tetra_channel_spacing_hz", "tetra_raster_offset_hz", "tetra_carrier_base_hz",
    "tetra_channel_half_width_hz", "allow_cli_sdr_fallback",
    "usb_reset_max_attempts", "phy_timing_phases",
)


def is_detector_key(key):
    """True for a calibrated detector constant rather than a user setting."""
    return key.startswith(_DETECTOR_PREFIXES) or key in _DETECTOR_KEYS


def _config_path():
    env = os.getenv("RFEYE_CONFIG")
    if env:
        return Path(env)
    if os.geteuid() == 0:
        return Path("/var/lib/rfeye/config.json")
    return Path.home() / ".config" / "rfeye" / "config.json"


def load_config():
    cfg = dict(DEFAULTS)
    p = _config_path()
    saved = {}
    try:
        if p.exists():
            saved = json.loads(p.read_text())
            cfg.update(saved)
    except Exception:
        saved = {}
    # RF Eye hardware profile is fixed for this branch too. Migrate stale
    # persisted GPIO18 settings when an existing unit receives the OTA update.
    cfg["buzzer_gpio"] = 26
    cfg["buzzer_model"] = "TMB12A03"
    cfg["buzzer_passive"] = False
    cfg["buzzer_active_high"] = True
    cfg["audio_mode"] = "adaptive"
    # Sensitive detection stopped being a setting in 0.9.33. A unit that had
    # the old Gevoelig toggle switched off would otherwise carry that through
    # the update and go on ignoring exactly the short control bursts this
    # release exists to catch, with nothing on screen to say so.
    cfg["uplink_sensitive"] = True
    # "auto" gain was the shipped value until 0.10.4 and every unit has it
    # saved. It is not a user setting -- there is no gain control on the
    # panel -- so the measured fixed gain replaces it; a unit that was given
    # a number by hand keeps its number.
    if cfg.get("gain") == "auto":
        cfg["gain"] = DEFAULTS["gain"]
    cfg["app_version"] = DEFAULTS["app_version"]
    cfg["update_manifest_url"] = DEFAULTS["update_manifest_url"]
    # Detector profile v8 replaces energy-statistics detection with real
    # ETSI EN 300 392-2 waveform verification. Every v6/v7 tuning key below
    # controlled a gate that no longer exists, so a unit upgrading from an
    # older profile must not carry its saved values forward -- they would
    # either do nothing or, where a name was reused, mean something else.
    #
    # Profile 9 additionally clears detector constants that earlier releases
    # persisted verbatim. Without this a unit first installed on 0.9.0 keeps
    # that release's acceptance limits for ever, because every later release
    # also reports profile 8 and the reset above never fires. save_config()
    # no longer writes these keys unless they differ from the default, so this
    # particular fossil cannot form again.
    #
    # Profile 10 moves the verification dwell from 288 kS/s to 2.016 MS/s. The
    # MHS35 reference config of every earlier install wrote the old dwell out
    # explicitly, so without this reset exactly those units would keep the
    # rate that locks phantom carriers.
    #
    # Profile 11 is the short-burst release. The claim in save_config() that
    # the fossil "cannot form again" was wrong for one path: install-cuqi35.sh
    # copies config/reference-config-cuqi35.json into place verbatim, detector
    # constants and all, so every unit installed from 0.9.29 onwards holds an
    # explicit phy_uplink_sensitive_percentile of 98 -- which would survive
    # this update and keep peak hold switched off on exactly the units that
    # need it. The site state is rebuilt too: locks made under the old
    # occupancy measurement are not evidence for the new one, and re-locking
    # costs about a minute.
    #
    # Profile 12 (0.10.3) lowers the weak-burst floor and lets one hit show.
    # ui_level_* was saved verbatim until now -- it was not counted as a
    # detector constant -- so without the reset the bar would keep its old
    # 8 dB bottom and a 5-8 dB detection would show nothing and stay silent.
    #
    # Profile 13 (0.10.8) widens the dwell from +-600 to +-850 kHz. The
    # reference config writes phy_max_offset_hz out, so every installed unit
    # holds the old width explicitly and would keep crossing the band in
    # five dwells instead of three.
    if int(saved.get("detector_profile_version", 0) or 0) < DETECTOR_PROFILE_VERSION:
        for key in list(DEFAULTS):
            if is_detector_key(key):
                cfg[key] = DEFAULTS[key]
    cfg["detector_profile_version"] = DETECTOR_PROFILE_VERSION
    # Power profile 1 (0.11.0) is drive mode by default. Every unit holds
    # low_power_mode explicitly -- the reference config writes it, and so does
    # every save -- so the new default alone would reach no installed unit.
    # Once: after this a unit that is switched back to ECO, by hand or by the
    # app on a sagging rail, keeps ECO.
    if int(saved.get("power_profile_version", 0) or 0) < POWER_PROFILE_VERSION:
        cfg["low_power_mode"] = DEFAULTS["low_power_mode"]
    cfg["power_profile_version"] = POWER_PROFILE_VERSION
    for obsolete in (
        # pre-v7 leftovers
        "threshold_db", "threshold_min_db", "threshold_max_db",
        "threshold_step_db", "threshold_soft_margin_db", "min_burst_span_db",
        "buzzer_duration_ms", "buzzer_high_hz", "buzzer_low_hz",
        # v6/v7 energy-statistics detector, removed in v8
        "artifact_calibration_sweeps", "artifact_min_baseline_hits",
        "artifact_rf_snr_delta_db", "artifact_duty_delta",
        "artifact_span_delta_db", "artifact_max_rf_snr_std_db",
        "artifact_max_duty_std", "artifact_max_span_std_db",
        "artifact_baseline_persist", "artifact_baseline_max_age_days",
        "artifact_comb_period_hz", "artifact_comb_half_width_hz",
        "artifact_comb_min_baseline_support", "artifact_comb_min_baseline_teeth",
        "artifact_comb_min_baseline_fraction", "artifact_comb_event_min_departure",
        "artifact_comb_event_min_teeth",
        "temporal_baseline_alpha", "temporal_state_max_age_s",
        "temporal_rf_snr_scale_db", "temporal_duty_scale",
        "temporal_span_scale_db", "broadband_temporal_min_departure",
        "broadband_dynamic_keep_max", "novelty_min_departure",
        "novelty_strong_departure", "max_mobile_candidates_per_sweep",
        "mobile_capture_ms", "site_capture_ms", "site_scan_interval",
        "fft_blocks", "burst_gate_db", "min_burst_duty", "max_burst_duty",
        "preferred_burst_duty_min", "preferred_burst_duty_max",
        "mobile_min_rf_snr_db", "site_min_snr_db", "site_burst_snr_db",
        "site_pair_memory_s", "site_pair_min_hits", "site_max_candidates",
        "duplex_pair_tolerance_hz", "duplex_pair_min_quality",
        "require_duplex_pair", "require_current_duplex_pair",
        "strong_pair_max_age_s", "strong_pair_min_quality",
        "strong_hit_confidence", "candidate_min_confidence",
        "confidence_attack", "confidence_release",
        "confidence_confirm", "confidence_clear",
        "uplink_confirm_window_s",
        "carrier_memory_s", "confirm_window_s", "alert_hold_s",
        "confirm_hits", "clear_hits",
        # replaced by the power ladder in 0.10.2
        "sdr_duty_recover", "sdr_duty_backoff_s",
    ):
        cfg.pop(obsolete, None)
    return cfg


def save_config(cfg):
    p = _config_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    # Write detector constants only where a value genuinely differs from the
    # shipped default. Anything equal to the default is left out so the next
    # release's calibration is picked up instead of being overridden by a
    # stale copy of its own former self.
    out = {k: v for k, v in cfg.items()
           if not (is_detector_key(k) and k in DEFAULTS and v == DEFAULTS[k])}
    text = json.dumps(out, indent=2) + "\n"
    try:
        if p.exists() and p.read_text() == text:
            return
    except Exception:
        pass
    tmp = p.with_name(p.name + ".tmp")
    tmp.write_text(text)
    tmp.replace(p)
