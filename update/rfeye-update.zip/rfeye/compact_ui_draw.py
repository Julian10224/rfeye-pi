"""Compact RF Eye drawing helpers for the CUQI 3.5-inch 320x480 portrait UI."""
from power import supply_text
BG=(2,3,5); PANEL=(8,9,12); BLUE=(0,152,222); BLUE_BRIGHT=(28,190,255)
WHITE=(224,229,236); DIM=(82,90,100); SEG_OFF=(34,35,31); GREEN=(57,205,91)
YELLOW=(243,192,56); RED=(230,54,54)

SETTINGS_TOP=62
# Eight rows since 0.9.33, when the Gevoelig toggle was removed: sensitive
# detection is the only mode now, so there is nothing to choose. The step
# stays at 44 rather than opening back up to 48 -- the rows are where the
# touch panel was calibrated for them, and the last one is clear of the
# "Made by" footer at y=463 with room to spare.
SETTINGS_STEP=44
SETTINGS_HEIGHT=40
SETTINGS_COUNT=8
# The slider is centred on the panel and kept clear of both edges: at
# X1=298 the 100% end sat 22px from the glass and a finger reached the
# enclosure wall before it reached maximum, so the row could not be driven
# past about 95%. Everything that reads the slider derives from these two.
BRIGHT_SLIDER_X0=60
BRIGHT_SLIDER_X1=260

def _clamp(v, lo=0.0, hi=1.0): return max(lo,min(hi,v))

def draw_gear(app,cx,cy,size=42):
    import math, pygame
    scale=4; side=max(48,int(size*scale)); icon=pygame.Surface((side,side),pygame.SRCALPHA)
    cc=side//2; teeth=10; outer=size*0.48*scale; root=size*0.34*scale; pts=[]
    for i in range(teeth*4):
        a=-math.pi/2+i*math.pi/(teeth*2); r=outer if i%4 in (1,2) else root
        pts.append((cc+int(math.cos(a)*r),cc+int(math.sin(a)*r)))
    pygame.draw.polygon(icon,BLUE_BRIGHT,pts)
    pygame.draw.circle(icon,BLUE_BRIGHT,(cc,cc),int(size*0.30*scale))
    pygame.draw.circle(icon,(0,0,0,0),(cc,cc),int(size*0.115*scale))
    icon=pygame.transform.smoothscale(icon,(int(size),int(size)))
    app.ui.blit(icon,icon.get_rect(center=(int(cx),int(cy))))


def _driver_name(snap):
    """Just the file name of the loaded librtlsdr; the path will not fit."""
    p=str(snap.get("driver_path") or "")
    return p.rsplit("/",1)[-1] if p else "?"


def _sdr_fault(error):
    """The one word that separates a missing dongle from a silent one.

    "not on bus" is a cable, a port or a supply; "read timeout" is a dongle
    that is enumerated and has stopped answering. They need opposite actions
    and the panel used to show neither.
    """
    low=str(error or "").lower()
    if not low:
        return ""
    if "not on the usb bus" in low or "open failed" in low:
        return "not on bus"
    if "stuck" in low:
        return "stuck capture"
    if "timeout" in low:
        return "read timeout"
    if "short read" in low:
        return "short read"
    if "no complete fft" in low:
        return "no samples"
    return str(error)[:12]


def _network_line(snap, status):
    """Headline status: what the detector is actually able to do right now."""
    if status=="DEMO":
        return "SDR DEMO",BLUE_BRIGHT
    if status in ("STARTING","SCANNING"):
        # Both mean the scan thread is on its way to the first dwell -- at
        # boot, and for the second or two after demo is switched off. Calling
        # that "SDR NOT CONNECTED" accused the hardware of a fault that had
        # not happened, and it was the first thing seen after leaving demo.
        return "STARTING SCAN",YELLOW
    if status!="LIVE":
        # A sagging 5 V rail and a broken dongle look identical on screen but
        # need completely different fixes, so say which one it is. This is the
        # live under-voltage bit only: the sticky "happened once since boot"
        # bit used to sit here and left the message up for ever.
        if snap.get("power_warning"):
            return "SDR LOST - USB POWER LOW",RED
        return "SDR NOT CONNECTED",RED
    state=str(snap.get("detector_state","SEARCHING"))
    if state=="ALERT":
        return "C2000 ACTIVITY NEARBY",RED
    if snap.get("network_locked"):
        return "C2000 LOCKED",GREEN
    return "SEARCHING FOR C2000",YELLOW


def draw_main(app, snap):
    import pygame
    app.ui.fill(BG)
    app._text("RF EYE",160,22,app.font_l,BLUE_BRIGHT,center=True)
    status=snap["status"]; scol=GREEN if status=="LIVE" else BLUE if status=="DEMO" else RED
    pygame.draw.circle(app.ui,scol,(294,22),5); app._gear(34,49,30)
    # The C2000 network state matters more than the USB state: without a
    # verified base station nearby the detector cannot report anything, and
    # the user needs to see that rather than read silence as "all clear".
    stxt,scol=_network_line(snap,status)
    app._text(stxt,160,52,app.font_s,scol,center=True)
    # While searching, say what the band pass is actually finding. "No RF at
    # all" and "a strong carrier that fails one test" look identical from a
    # status word, and telling those apart is the whole question when a unit
    # sits on SEARCHING.
    if status=="LIVE" and not snap.get("network_locked"):
        sb=snap.get("search_best") or {}
        if sb:
            app._text("%.4f %+.0fdB %s"%(float(sb.get("freq_hz",0.0))/1e6,
                float(sb.get("snr_db",0.0)),
                "TETRA" if sb.get("ok") else str(sb.get("fail") or "?").split(",")[0]),
                160,72,app.font_s,DIM,center=True)
    peaks=list(snap["peaks"][:3])
    while len(peaks)<3: peaks.append({"level":0.0,"freq_hz":0.0})
    if not hasattr(app,"_last_peak_freqs"):
        app._last_peak_freqs=[381_000_000.0,382_500_000.0,384_000_000.0]
    for col,p in enumerate(peaks):
        x=[16,112,208][col]; level=_clamp(float(p.get("level",0.0))); active=int(round(level*10))
        for i in range(10):
            yy=90+(9-i)*21; color=app._level_color(i,10) if i<active else SEG_OFF
            pygame.draw.rect(app.ui,color,(x,yy,80,17),border_radius=3)
        if app.cfg.get("show_frequency",True):
            freq=float(p.get("freq_hz",0.0) or 0.0)
            if freq>0.0 and level>=0.15:
                app._last_peak_freqs[col]=freq
            shown=app._last_peak_freqs[col]
            app._text(f'{shown/1e6:.3f}',x+40,322,app.font_s,(132,184,210),center=True)
            app._text("MHz",x+40,342,app.font_s,DIM,center=True)
    lv=float(snap.get("mobile_level",0.0))
    if status not in ("LIVE","DEMO"):
        state,col=("POWER",RED) if snap.get("power_warning") else ("NO SDR",RED)
    elif status=="LIVE" and not snap.get("network_locked") and lv<=0.15:
        state,col="NO NET",BLUE_BRIGHT
    elif lv>0.72: state,col="HIGH",RED
    elif lv>0.43: state,col="MEDIUM",YELLOW
    elif lv>0.15: state,col="LOW",GREEN
    else: state,col="CLEAR",DIM
    pygame.draw.rect(app.ui,PANEL,(0,360,320,120))
    for rect in [(8,374,94,90),(112,374,96,90),(218,374,94,90)]: pygame.draw.rect(app.ui,(17,20,25),rect,border_radius=11)
    app._text("MUTED" if app.cfg.get("muted") else "SOUND",55,405,app.font_m,RED if app.cfg.get("muted") else BLUE_BRIGHT,center=True)
    app._text("tap",55,438,app.font_s,DIM,center=True)
    import math, time
    rec_left=(float(getattr(app,"rf_record_end",0.0))-time.monotonic()
              if bool(getattr(app,"rf_recording",False)) else 0.0)
    if rec_left>0.0:
        # While recording, the middle tile counts the capture down in place of
        # the lock count, then returns to it when the recording finishes.
        app._text("%d"%int(math.ceil(rec_left)),160,402,app.font_l,RED,center=True)
        app._text("REC",160,438,app.font_s,RED,center=True)
    else:
        nlock=int(snap.get("site_locked_count",0) or 0)
        app._text(str(nlock),160,402,app.font_l,GREEN if nlock else DIM,center=True)
        app._text("LOCKED",160,438,app.font_s,DIM,center=True)
    app._text(state,265,405,app.font_m if len(state)<7 else app.font_s,col,center=True); app._text("status",265,438,app.font_s,DIM,center=True)

def draw_settings(app):
    import pygame, time
    app.ui.fill(BG); pygame.draw.rect(app.ui,(7,11,16),(0,0,320,60))
    app._text("‹",18,26,app.font_xl,BLUE_BRIGHT,center=True); app._text("SETTINGS",48,12,app.font_l,WHITE)
    app._text(f'RF EYE v{app.cfg.get("app_version","")}',50,39,app.font_s,DIM)
    rows=[
        ("Demo","ON" if app.cfg.get("demo_mode") else "OFF","toggle"),
        ("Brightness",f'{int(round(float(app.cfg.get("brightness",1.0))*100))}%',"brightness_slider"),
        ("Max power","OFF" if app.cfg.get("low_power_mode",True) else "ON","toggle"),
        ("Record RF",(f'REC {max(0,int(round(float(getattr(app,"rf_record_end",0.0))-time.monotonic())))}s' if bool(getattr(app,"rf_recording",False)) else (getattr(app,"rf_record_message","SAVE") if time.monotonic()<float(getattr(app,"rf_record_message_until",0.0)) else "SAVE")),"action"),
        ("Recordings","OPEN","action"),
        ("Wi-Fi",app._wifi_text(),"status"),
        ("Update",app.update_message,"action"),
        ("Debug","OPEN","action"),
    ]
    for i,(label,value,kind) in enumerate(rows):
        y=SETTINGS_TOP+i*SETTINGS_STEP
        pygame.draw.rect(app.ui,(9,13,18),(8,y,304,SETTINGS_HEIGHT),border_radius=8)
        if kind=="brightness_slider":
            app._text(label,18,y+4,app.font_s,WHITE)
            surf=app.font_s.render(str(value),True,(150,201,226)); app.ui.blit(surf,(302-surf.get_width(),y+4))
            lo,hi=0.4,1.0; val=max(lo,min(hi,float(app.cfg.get("brightness",1.0)))); x0,x1=BRIGHT_SLIDER_X0,BRIGHT_SLIDER_X1
            n=0.0 if hi<=lo else (val-lo)/(hi-lo); sy=y+29; sx=x0+int(round(n*(x1-x0)))
            pygame.draw.line(app.ui,(38,43,49),(x0,sy),(x1,sy),5); pygame.draw.line(app.ui,BLUE,(x0,sy),(sx,sy),5); pygame.draw.circle(app.ui,WHITE,(sx,sy),7)
            continue
        app._text(label,18,y+13,app.font_s,WHITE)
        if kind=="toggle":
            enabled=value=="ON"; pygame.draw.rect(app.ui,BLUE if enabled else (38,43,49),(252,y+11,50,24),border_radius=12); pygame.draw.circle(app.ui,WHITE,(289 if enabled else 265,y+23),9)
        else:
            col=GREEN if kind=="status" and value=="CONNECTED" else (RED if kind=="status" else BLUE_BRIGHT if kind=="action" else (150,201,226))
            shown=str(value); shown=shown if len(shown)<=13 else shown[:12]+"…"
            surf=app.font_s.render(shown,True,col); app.ui.blit(surf,(302-surf.get_width(),y+13))
    app._text("Made by: Julian",160,463,app.font_s,DIM,center=True)

def draw_debug(app,snap):
    import pygame, time
    app.ui.fill(BG); pygame.draw.rect(app.ui,(7,11,16),(0,0,320,60))
    app._text("‹",18,26,app.font_xl,BLUE_BRIGHT,center=True); app._text("DEBUG",48,10,app.font_l,WHITE)
    app._text("LIVE PERFORMANCE",50,38,app.font_s,DIM)
    age_ms=max(0.0,(time.time()-float(snap.get("last_update",0.0)))*1000.0) if snap.get("last_update") else 0.0
    frame_ms=max(0.001,float(getattr(app,"debug_frame_ms",0.0) or 0.001))
    phy=list(snap.get("phy") or [])
    best=max(phy,key=lambda q:float(q.get("dqpsk_m",0)),default=None)
    sb=snap.get("search_best") or {}
    rows=[("UI refresh",f"{frame_ms:.1f} ms / {1000.0/frame_ms:.1f} FPS"),
          ("Detector",str(snap.get("detector_state","?"))),
          ("Sites locked",f"{int(snap.get('site_locked_count',0))} / cand {int(snap.get('site_candidate_count',0))}"),
          ("Watching",f"{len(snap.get('watch_freqs') or [])} ch {str(snap.get('dwell_role','')).lower()}"),
          ("Best DQPSK",("%.3f sel %.1f"%(float(best.get("dqpsk_m",0)),float(best.get("dqpsk_selectivity",0)))) if best else "-"),
          ("Verdict",(str(best.get("reason","?"))[:20]) if best else "-"),
          # What this pass actually found, and the check it fell over on.
          # Half an hour of "SEARCHING" says nothing on its own; this says
          # whether the band is empty or a limit is refusing a real carrier.
          ("Best channel",("%.4f MHz"%(float(sb.get("freq_hz",0.0))/1e6)) if sb else "-"),
          ("  its verdict",(("%+.1f dB %s"%(float(sb.get("snr_db",0.0)),
              "TETRA" if sb.get("ok") else str(sb.get("fail") or "?"))) if sb else "-")),
          ("Cycle / dwell",f"{float(snap.get('cycle_ms',0)):.0f} / {float(snap.get('dwell_ms',0)):.0f} ms"),
          ("Verify",f"{float(snap.get('verify_ms',0)):.0f} ms  age {age_ms:.0f} ms"),
          ("Last band pass",(f"{float(snap.get('last_pass_s',0)):.0f} s"
                             if float(snap.get("last_pass_s",0)) else "-")),
          # Which librtlsdr is loaded. A build with no code path for the
          # dongle never throws its RF switch and the whole band reads as
          # noise -- a fault with no other symptom at all.
          ("Driver",("BLOG %s" % _driver_name(snap)) if snap.get("driver_knows_model")
                    else ("PLAIN %s" % _driver_name(snap))),
          # The rail, how often it dipped and what the power ladder holds the
          # radio to because of it, e.g. "DIPPED x2 cap 30% +4m".
          ("Supply",supply_text(snap)),
          # When the radio is unhappy its own words are worth more than the
          # code path it was opened through.
          ("Backend",(f"{snap.get('status','?')} {_sdr_fault(snap.get('error'))}"
                      if _sdr_fault(snap.get("error"))
                      else f"{snap.get('status','?')} {str(snap.get('sdr_path','?'))[:9]}"))]
    y=64
    for label,value in rows:
        # 14 rows now, so the step tightened again. 64 + 14*25 = 414, which
        # keeps the calibrate button at y=420 clear.
        pygame.draw.rect(app.ui,(9,13,18),(8,y,304,23),border_radius=6); app._text(label,16,y+4,app.font_s,DIM)
        shown=value if len(value)<=22 else value[:21]+"…"; col=GREEN if label=="Backend" and value=="LIVE" else BLUE_BRIGHT
        surf=app.font_s.render(shown,True,col); app.ui.blit(surf,(304-surf.get_width(),y+4)); y+=25
    pygame.draw.rect(app.ui,(12,24,32),(8,420,304,30),border_radius=8)
    app._text("Touch calibration",18,427,app.font_s,WHITE)
    surf=app.font_s.render("CALIBRATE",True,BLUE_BRIGHT); app.ui.blit(surf,(302-surf.get_width(),427))
    msg=str(getattr(app,"low_power_message","") or "")
    if msg and time.monotonic() < float(getattr(app,"low_power_message_until",0.0)):
        app._text(msg,160,465,app.font_s,BLUE_BRIGHT,center=True)
    else:
        app._text("tap top/bottom to return",160,465,app.font_s,DIM,center=True)

def draw_recordings(app):
    import pygame
    from compact_ui_controls import _refresh_recordings
    entries=getattr(app,"recording_entries",None)
    if entries is None:
        entries=_refresh_recordings(app)
    off=int(getattr(app,"recording_offset",0))
    app.ui.fill(BG); pygame.draw.rect(app.ui,(7,11,16),(0,0,320,60))
    app._text("‹",18,26,app.font_xl,BLUE_BRIGHT,center=True)
    app._text("RECORDINGS",48,12,app.font_l,WHITE)
    app._text(f"{len(entries)} saved",50,39,app.font_s,DIM)
    if not entries:
        app._text("No recordings",160,214,app.font_m,DIM,center=True)
        app._text("Use Record RF in Settings",160,244,app.font_s,DIM,center=True)
    else:
        for i,e in enumerate(entries[off:off+6]):
            y=70+i*54
            pygame.draw.rect(app.ui,(9,13,18),(8,y,304,48),border_radius=8)
            label=str(e.get("label",""))
            date=label[:10]; tm=label[11:19] if len(label)>=19 else ""
            app._text(date,18,y+7,app.font_s,WHITE)
            app._text(tm,18,y+25,app.font_s,(150,201,226))
            mode=str(e.get("mode",""))
            col=GREEN if mode.startswith("PHY v8") else YELLOW
            surf=app.font_s.render(mode,True,col); app.ui.blit(surf,(302-surf.get_width(),y+7))
            info=f'{int(e.get("samples",0))} samples'
            surf=app.font_s.render(info,True,DIM); app.ui.blit(surf,(302-surf.get_width(),y+25))
    pygame.draw.rect(app.ui,(12,18,24),(8,408,148,48),border_radius=9)
    pygame.draw.rect(app.ui,(12,18,24),(164,408,148,48),border_radius=9)
    app._text("NEWER",82,432,app.font_s,BLUE_BRIGHT,center=True)
    app._text("OLDER",238,432,app.font_s,BLUE_BRIGHT,center=True)
    app._text("tap recording for details",160,468,app.font_s,DIM,center=True)


def draw_recording_detail(app):
    import pygame
    e=getattr(app,"recording_selected",None) or {}
    app.ui.fill(BG); pygame.draw.rect(app.ui,(7,11,16),(0,0,320,60))
    app._text("‹",18,26,app.font_xl,BLUE_BRIGHT,center=True)
    app._text("RECORDING",48,12,app.font_l,WHITE)
    app._text(str(e.get("label","Unknown"))[:19],50,39,app.font_s,DIM)
    mode=str(e.get("mode","PRE-v8 ARCHIVE"))
    col=GREEN if mode.startswith("PHY v8") else YELLOW
    app._text(mode,160,94,app.font_m,col,center=True)
    app._text(f'{int(e.get("samples",0))} samples',160,126,app.font_s,WHITE,center=True)
    dur=float(e.get("duration",0.0) or 0.0)
    app._text(f'{dur:.0f} s recorded',160,149,app.font_s,DIM,center=True)
    if not mode.startswith("PHY v8"):
        app._text("Recorded before profile v8:",160,172,app.font_s,YELLOW,center=True)
        app._text("shown as archived, not re-analysed",160,192,app.font_s,YELLOW,center=True)
    pygame.draw.rect(app.ui,(12,91,132),(12,188,296,98),border_radius=16)
    app._text("PLAY",160,224,app.font_l,WHITE,center=True)
    app._text("Replay detector + sound",160,257,app.font_s,WHITE,center=True)
    pygame.draw.rect(app.ui,(92,28,34),(12,316,296,98),border_radius=16)
    app._text("DELETE",160,352,app.font_l,WHITE,center=True)
    app._text("Remove this recording",160,385,app.font_s,WHITE,center=True)
    if bool(getattr(app,"recording_delete_error",False)):
        app._text("Delete failed",160,438,app.font_s,RED,center=True)
    else:
        app._text("tap top to return",160,454,app.font_s,DIM,center=True)


def draw_recording_delete_confirm(app):
    import pygame
    e=getattr(app,"recording_selected",None) or {}
    app.ui.fill(BG)
    app._text("DELETE RECORDING",160,48,app.font_l,RED,center=True)
    app._text(str(e.get("label",""))[:19],160,91,app.font_m,WHITE,center=True)
    app._text("This cannot be undone.",160,132,app.font_s,DIM,center=True)
    pygame.draw.rect(app.ui,(34,39,46),(12,205,296,112),border_radius=16)
    pygame.draw.rect(app.ui,(92,28,34),(12,350,296,105),border_radius=16)
    app._text("NO",160,248,app.font_l,WHITE,center=True)
    app._text("Keep recording",160,282,app.font_s,DIM,center=True)
    app._text("YES",160,388,app.font_l,WHITE,center=True)
    app._text("Delete permanently",160,421,app.font_s,WHITE,center=True)


def draw_recording_replay(app):
    import pygame
    e=getattr(app,"recording_selected",None) or {}
    snap=getattr(app,"recording_replay_snapshot",None)
    running=bool(getattr(app,"recording_replay_running",False))
    finished=bool(getattr(app,"recording_replay_finished",False))
    total=max(1,int(getattr(app,"recording_replay_total",0) or 1))
    idx=int(getattr(app,"recording_replay_index",0))
    alerts=int(getattr(app,"recording_replay_alerts",0))
    mode=str(getattr(app,"recording_replay_mode",e.get("mode","")))
    app.ui.fill(BG); pygame.draw.rect(app.ui,(7,11,16),(0,0,320,60))
    app._text("‹",18,26,app.font_xl,BLUE_BRIGHT,center=True)
    app._text("REPLAY",48,12,app.font_l,WHITE)
    app._text(str(e.get("label",""))[:19],50,39,app.font_s,DIM)
    col=GREEN if mode=="EXACT v5" else YELLOW
    app._text(mode,300,22,app.font_s,col,right=True)
    plot=pygame.Rect(12,78,296,188)
    pygame.draw.rect(app.ui,(7,8,10),plot); pygame.draw.rect(app.ui,(45,48,54),plot,1)
    if snap:
        spectrum=list(snap.get("spectrum") or [])
        if len(spectrum)>2:
            pmin=float(snap.get("noise",-100))-12
            pmax=max(max(float(v) for v in spectrum),pmin+45)
            pts=[]
            for i,v in enumerate(spectrum):
                x=plot.left+int(i*(plot.width-1)/(len(spectrum)-1))
                n=_clamp((float(v)-pmin)/(pmax-pmin))
                y=plot.bottom-int(n*(plot.height-1)); pts.append((x,y))
            if len(pts)>1: pygame.draw.lines(app.ui,BLUE_BRIGHT,False,pts,1)
    frac=max(0.0,min(1.0,float(idx)/float(total)))
    pygame.draw.rect(app.ui,(25,31,38),(12,278,296,10),border_radius=5)
    pygame.draw.rect(app.ui,BLUE,(12,278,int(296*frac),10),border_radius=5)
    app._text(f"{idx}/{total}",20,300,app.font_s,DIM)
    app._text(f"ALERTS {alerts}",300,300,app.font_s,RED if alerts else DIM,right=True)
    if snap and snap.get("peaks"):
        q=snap["peaks"][0]
        app._text("ALERT",160,333,app.font_l,RED,center=True)
        app._text(f'{float(q.get("freq_hz",0))/1e6:.5f} MHz',160,362,app.font_m,WHITE,center=True)
        app._text(f'confidence {float(q.get("confidence",0)):.2f}',160,386,app.font_s,YELLOW,center=True)
    elif finished:
        app._text("REPLAY DONE",160,342,app.font_l,GREEN,center=True)
        app._text(f"{alerts} alert sample(s)",160,374,app.font_s,WHITE,center=True)
    elif running:
        app._text("PLAYING",160,342,app.font_l,BLUE_BRIGHT,center=True)
        app._text("no alert in current sample",160,374,app.font_s,DIM,center=True)
    else:
        err=str(getattr(app,"recording_replay_error",""))
        app._text("REPLAY STOPPED",160,342,app.font_l,DIM,center=True)
        if err: app._text(err[:38],160,374,app.font_s,RED,center=True)
    pygame.draw.rect(app.ui,(24,29,35),(12,408,296,48),border_radius=10)
    app._text("STOP / BACK",160,432,app.font_m,WHITE,center=True)
    app._text("Replay sound follows detector alerts",160,469,app.font_s,DIM,center=True)


def draw_record_confirm(app):
    import pygame
    app.ui.fill(BG)
    app._text("RF RECORDING",160,54,app.font_l,BLUE_BRIGHT,center=True)
    app._text("Weet je het zeker?",160,112,app.font_m,WHITE,center=True)
    app._text("Een opname wordt als testdata opgeslagen.",160,151,app.font_s,DIM,center=True)
    app._text("Start alleen als dit bewust de juiste situatie is.",160,177,app.font_s,DIM,center=True)
    pygame.draw.rect(app.ui,(34,39,46),(12,215,296,112),border_radius=16)
    pygame.draw.rect(app.ui,(12,91,132),(12,350,296,105),border_radius=16)
    app._text("NEE",160,258,app.font_l,WHITE,center=True)
    app._text("Annuleren",160,292,app.font_s,DIM,center=True)
    app._text("JA",160,388,app.font_l,WHITE,center=True)
    app._text("Opname starten",160,421,app.font_s,WHITE,center=True)

def draw_demo_confirm(app):
    """Ask before switching demo on -- and only before switching it on.

    Demo is the first row in Settings, one tap away from the gear, and it
    replaces the whole display with synthetic traffic. Catching it by accident
    means the appliance sits there inventing signals while a real drive goes
    unwatched. Switching it back off needs no ceremony: that direction can only
    make the display more honest.

    Same layout as the recording dialog on purpose -- NEE is the large upper
    button and the default for every tap outside the separated lower JA, which
    is what makes it safe on a resistive panel with imperfect calibration.
    """
    import pygame
    app.ui.fill(BG)
    app._text("DEMO MODUS",160,54,app.font_l,YELLOW,center=True)
    app._text("Weet je het zeker?",160,112,app.font_m,WHITE,center=True)
    app._text("Het scherm toont dan verzonnen signalen.",160,151,app.font_s,DIM,center=True)
    app._text("Er wordt niet meer naar C2000 geluisterd.",160,177,app.font_s,DIM,center=True)
    pygame.draw.rect(app.ui,(34,39,46),(12,215,296,112),border_radius=16)
    pygame.draw.rect(app.ui,(96,74,12),(12,350,296,105),border_radius=16)
    app._text("NEE",160,258,app.font_l,WHITE,center=True)
    app._text("Annuleren",160,292,app.font_s,DIM,center=True)
    app._text("JA",160,388,app.font_l,WHITE,center=True)
    app._text("Demo aanzetten",160,421,app.font_s,WHITE,center=True)

def draw_calibration(app):
    import pygame
    from compact_ui_controls import CALIBRATION_TARGETS
    app.ui.fill(BG)
    app._text("TOUCH CALIBRATION",160,22,app.font_l,BLUE_BRIGHT,center=True)
    idx=int(getattr(app,'touch_calibration_index',0)); done=bool(getattr(app,'touch_calibration_complete',False))
    if done:
        ok='FAILED' not in str(getattr(app,'touch_calibration_message',''))
        app._text(getattr(app,'touch_calibration_message','CALIBRATION APPLIED'),160,190,app.font_m,GREEN if ok else RED,center=True)
        app._text("New calibration is active",160,224,app.font_s,WHITE,center=True)
        app._text("Tap anywhere to return",160,270,app.font_s,DIM,center=True)
        return
    app._text(f"Point {idx+1} of {len(CALIBRATION_TARGETS)}",160,54,app.font_s,DIM,center=True)
    app._text("Tap the center of the cross",160,77,app.font_s,WHITE,center=True)
    tx,ty=CALIBRATION_TARGETS[min(idx,len(CALIBRATION_TARGETS)-1)]
    pygame.draw.circle(app.ui,BLUE_BRIGHT,(tx,ty),13,2); pygame.draw.line(app.ui,BLUE_BRIGHT,(tx-18,ty),(tx+18,ty),2); pygame.draw.line(app.ui,BLUE_BRIGHT,(tx,ty-18),(tx,ty+18),2); pygame.draw.circle(app.ui,WHITE,(tx,ty),3)
    app._text("Use a precise fingertip/stylus",160,466,app.font_s,DIM,center=True)
